﻿// Farmer Produce Marketing - Directorate Admin Controller
const Admin = {
  stats: {},
  orders: [],
  users: [],
  logisticsOptions: {
    collectionCentres: [],
    districtHubs: [],
    deliveryPartners: []
  },
  activeTab: 'orders',
  currentOrderId: null,

  async init() {
    if (!State.currentUser || State.currentUser.role !== 'admin') {
      Toast.show('Access restricted. Please log in as Administrator.', 'error');
      App.showAuthModal('login');
      return;
    }

    try {
      await this.loadLogisticsOptions();
      await this.loadDashboardData();
      await this.loadUsers();
    } catch (err) {
      console.error('Admin init error:', err);
      Toast.show('Failed to initialize administrator dashboard.', 'error');
    }
  },

  async loadLogisticsOptions() {
    try {
      const res = await API.getLogisticsOptions();
      if (res.success) {
        this.logisticsOptions = {
          collectionCentres: res.collectionCentres || [],
          districtHubs: res.districtHubs || [],
          deliveryPartners: res.deliveryPartners || []
        };
        this.populateLogisticsDropdowns();
      }
    } catch (err) {
      console.error('Failed to load logistics options:', err);
    }
  },

  populateLogisticsDropdowns() {
    const centreSelect = document.getElementById('assign-centre-select');
    const hubSelect = document.getElementById('assign-hub-select');
    const partnerSelect = document.getElementById('assign-partner-select');

    if (centreSelect) {
      centreSelect.innerHTML = '<option value="">-- Select Village Collection Centre --</option>' +
        this.logisticsOptions.collectionCentres.map(c => `
          <option value="${c.name} [Incharge: ${c.incharge}]">${c.name} (${c.district}) - ${c.capacityKg}kg capacity</option>
        `).join('');
    }

    if (hubSelect) {
      hubSelect.innerHTML = '<option value="">-- Select District Logistics Hub --</option>' +
        this.logisticsOptions.districtHubs.map(h => `
          <option value="${h.name} [Mgr: ${h.manager}]">${h.name} (${h.district}) - Cold Storage: ${h.coldStorageAvailable ? 'Yes' : 'No'}</option>
        `).join('');
    }

    if (partnerSelect) {
      partnerSelect.innerHTML = '<option value="">-- Select Delivery Partner --</option>' +
        this.logisticsOptions.deliveryPartners.map(p => `
          <option value="${p.name} (${p.agency} - ${p.phone})">${p.name} (${p.agency}) - ${p.vehicle} [${p.district}]</option>
        `).join('');
    }
  },

  async loadDashboardData() {
    try {
      const res = await API.getAdminDashboard();
      if (res.success) {
        this.stats = res.stats || {};
        this.orders = res.recentOrders || [];
        this.renderKPIs(this.stats);
        this.renderDistrictSales(res.salesByDistrict || {});
        this.renderTopProducts(res.topProducts || []);
      }

      // Load full order list
      const orderRes = await API.getOrders();
      this.orders = orderRes.orders || [];
      this.renderOrdersTable(this.orders);
    } catch (err) {
      console.error('Error loading admin dashboard:', err);
      Toast.show('Error loading admin statistics.', 'error');
    }
  },

  renderKPIs(s) {
    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setVal('kpi-admin-sales', `₹${(s.totalSales || 0).toLocaleString('en-IN')}`);
    setVal('kpi-admin-farmers', s.totalFarmers || 0);
    setVal('kpi-admin-customers', s.totalCustomers || 0);
    setVal('kpi-admin-orders', s.totalOrders || 0);
    setVal('kpi-admin-pending', s.pendingOrders || 0);
    setVal('kpi-admin-hubs', (s.collectionCentresCount || 0) + (s.districtHubsCount || 0));
  },

  renderOrdersTable(orders) {
    const tbody = document.getElementById('admin-orders-tbody');
    if (!tbody) return;

    if (!orders || orders.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" style="text-align:center; padding:2rem; color:var(--slate-500);">
            No orders found in the platform.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = orders.map(order => {
      let badgeClass = 'badge-placed';
      if (order.orderStatus === 'FARMER_CONFIRMED') badgeClass = 'badge-confirmed';
      if (order.orderStatus.includes('TRANSIT') || order.orderStatus.includes('COLLECTION') || order.orderStatus.includes('HUB') || order.orderStatus.includes('DELIVERY')) badgeClass = 'badge-transit';
      if (order.orderStatus === 'DELIVERED') badgeClass = 'badge-delivered';
      if (order.orderStatus === 'CANCELLED') badgeClass = 'badge-cancelled';

      const itemsList = order.items.map(i => `${i.name} (×${i.quantity})`).join(', ');

      return `
        <tr>
          <td><strong style="color:var(--primary); font-family:monospace;">#${order.id}</strong></td>
          <td>
            <div style="font-weight:700; color:var(--slate-900);">${order.customerName}</div>
            <div style="font-size:0.75rem; color:var(--slate-500);">📞 ${order.customerPhone} • 📍 ${order.deliveryAddress?.district}</div>
          </td>
          <td style="max-width:200px; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${itemsList}">
            ${itemsList}
          </td>
          <td><strong style="color:var(--slate-900);">₹${order.total}</strong></td>
          <td><span class="badge ${badgeClass}">${order.orderStatus.replace(/_/g, ' ')}</span></td>
          <td style="font-size:0.78rem;">
            <div style="color:var(--slate-700);">🏢 ${order.logistics?.collectionCentre || '<span style="color:var(--warning);">Pending Assign</span>'}</div>
            <div style="color:var(--slate-500); margin-top:0.15rem;">🚚 ${order.logistics?.deliveryPerson || 'Unassigned'}</div>
          </td>
          <td>
            <div style="display:flex; gap:0.35rem; flex-wrap:wrap;">
              <button class="btn btn-secondary btn-sm" onclick="Admin.openLogisticsModal('${order.id}')" title="Assign Logistics Route">
                🏢 Route
              </button>
              <button class="btn btn-primary btn-sm" onclick="Admin.openStatusModal('${order.id}')" title="Advance Delivery Stage">
                ⚡ Stage
              </button>
              <button class="btn btn-secondary btn-sm" onclick="App.showOrderTracking('${order.id}')" title="View Timeline">
                📍 Track
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openLogisticsModal(orderId) {
    const order = this.orders.find(o => o.id === orderId);
    if (!order) return;

    this.currentOrderId = orderId;
    document.getElementById('assign-order-id-label').textContent = orderId;
    document.getElementById('assign-order-district').textContent = `${order.deliveryAddress?.district}, Tamil Nadu (Pincode: ${order.deliveryAddress?.pincode})`;

    const centreSelect = document.getElementById('assign-centre-select');
    const hubSelect = document.getElementById('assign-hub-select');
    const partnerSelect = document.getElementById('assign-partner-select');

    if (centreSelect && order.logistics?.collectionCentre) {
      centreSelect.value = order.logistics.collectionCentre;
    }
    if (hubSelect && order.logistics?.districtHub) {
      hubSelect.value = order.logistics.districtHub;
    }
    if (partnerSelect && order.logistics?.deliveryPerson) {
      partnerSelect.value = order.logistics.deliveryPerson;
    }

    App.openModal('admin-logistics-modal');
  },

  async handleLogisticsSubmit(e) {
    e.preventDefault();
    if (!this.currentOrderId) return;

    const collectionCentre = document.getElementById('assign-centre-select').value;
    const districtHub = document.getElementById('assign-hub-select').value;
    const deliveryPerson = document.getElementById('assign-partner-select').value;

    try {
      await API.assignLogistics(this.currentOrderId, {
        collectionCentre,
        districtHub,
        deliveryPerson
      });
      Toast.show(`Logistics assigned for Order #${this.currentOrderId}`, 'success');
      App.closeModal('admin-logistics-modal');
      await this.loadDashboardData();
    } catch (err) {
      Toast.show(err.message || 'Failed to assign logistics.', 'error');
    }
  },

  openStatusModal(orderId) {
    const order = this.orders.find(o => o.id === orderId);
    if (!order) return;

    this.currentOrderId = orderId;
    document.getElementById('status-order-id-label').textContent = orderId;
    document.getElementById('admin-status-select').value = order.orderStatus;
    document.getElementById('admin-status-location').value = order.deliveryAddress?.district || 'Tamil Nadu';
    document.getElementById('admin-status-note').value = '';

    App.openModal('admin-status-modal');
  },

  async handleStatusSubmit(e) {
    e.preventDefault();
    if (!this.currentOrderId) return;

    const status = document.getElementById('admin-status-select').value;
    const location = document.getElementById('admin-status-location').value.trim();
    const note = document.getElementById('admin-status-note').value.trim();

    try {
      await API.updateOrderStatus(this.currentOrderId, {
        status,
        location,
        note
      });
      Toast.show(`Order #${this.currentOrderId} updated to ${status} [AWS SNS dispatched]`, 'success');
      App.closeModal('admin-status-modal');
      await this.loadDashboardData();
    } catch (err) {
      Toast.show(err.message || 'Failed to update order status.', 'error');
    }
  },

  async loadUsers(role = '') {
    try {
      const res = await API.getAdminUsers(role);
      if (res.success) {
        this.users = res.users || [];
        this.renderUsersTable(this.users);
      }
    } catch (err) {
      console.error('Error loading users:', err);
    }
  },

  renderUsersTable(users) {
    const tbody = document.getElementById('admin-users-tbody');
    if (!tbody) return;

    tbody.innerHTML = users.map(u => {
      let roleBadge = '<span class="badge badge-confirmed">Farmer</span>';
      if (u.role === 'customer') roleBadge = '<span class="badge badge-placed">Customer</span>';
      if (u.role === 'admin') roleBadge = '<span class="badge badge-transit">State Admin</span>';

      return `
        <tr>
          <td>
            <div style="font-weight:700; color:var(--slate-900);">${u.name}</div>
            <div style="font-size:0.75rem; color:var(--slate-500);">${u.farmName || 'Direct Consumer'}</div>
          </td>
          <td>${roleBadge}</td>
          <td>${u.email}</td>
          <td>${u.phone || 'N/A'}</td>
          <td>📍 ${u.district}, ${u.state || 'Tamil Nadu'}</td>
          <td>
            ${u.role !== 'admin' ? `
              <button class="btn btn-danger btn-sm" onclick="Admin.deleteUser('${u.id}', '${u.name.replace(/'/g, "\\'")}')" title="Delete User">
                🗑️ Remove
              </button>
            ` : '<span style="font-size:0.75rem; color:var(--slate-400);">System Protected</span>'}
          </td>
        </tr>
      `;
    }).join('');
  },

  async deleteUser(id, name) {
    if (!confirm(`Are you sure you want to remove user "${name}" from the system?`)) {
      return;
    }

    try {
      await API.deleteUser(id);
      Toast.show(`User "${name}" deleted successfully.`, 'info');
      await this.loadUsers();
      await this.loadDashboardData();
    } catch (err) {
      Toast.show(err.message || 'Failed to remove user.', 'error');
    }
  },

  renderDistrictSales(districtSales) {
    const container = document.getElementById('admin-district-sales-list');
    if (!container) return;

    const entries = Object.entries(districtSales).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) {
      container.innerHTML = '<p style="color:var(--slate-400); font-size:0.85rem;">No district sales recorded yet.</p>';
      return;
    }

    const maxVal = entries[0][1] || 1;

    container.innerHTML = entries.map(([district, total]) => {
      const pct = Math.min(100, Math.round((total / maxVal) * 100));
      return `
        <div style="margin-bottom: 0.85rem;">
          <div style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:0.25rem;">
            <strong style="color:var(--slate-800);">📍 ${district}</strong>
            <span style="font-weight:700; color:var(--primary);">₹${total.toLocaleString('en-IN')}</span>
          </div>
          <div style="background:var(--slate-100); height:8px; border-radius:var(--radius-full); overflow:hidden;">
            <div style="background:var(--primary); height:100%; width:${pct}%; border-radius:var(--radius-full);"></div>
          </div>
        </div>
      `;
    }).join('');
  },

  renderTopProducts(topProducts) {
    const container = document.getElementById('admin-top-products-list');
    if (!container) return;

    if (!topProducts || topProducts.length === 0) {
      container.innerHTML = '<p style="color:var(--slate-400); font-size:0.85rem;">No sales data available yet.</p>';
      return;
    }

    container.innerHTML = topProducts.map(p => `
      <div style="display:flex; align-items:center; justify-content:space-between; padding:0.6rem 0; border-bottom:1px solid var(--slate-100);">
        <div>
          <div style="font-weight:700; font-size:0.88rem; color:var(--slate-900);">${p.name}</div>
          <div style="font-size:0.75rem; color:var(--slate-500);">District: ${p.district || 'Tamil Nadu'} • Quantity Sold: ${p.quantity} units</div>
        </div>
        <div style="font-weight:800; color:var(--accent); font-size:0.95rem;">₹${p.revenue.toLocaleString('en-IN')}</div>
      </div>
    `).join('');
  },

  switchTab(tabId) {
    this.activeTab = tabId;
    const tabBtns = document.querySelectorAll('.admin-tab-btn');
    const sections = document.querySelectorAll('.admin-tab-content');

    tabBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabId);
    });

    sections.forEach(sec => {
      sec.style.display = sec.id === `admin-tab-${tabId}` ? 'block' : 'none';
    });
  }
};
