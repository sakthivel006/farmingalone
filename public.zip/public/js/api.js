// Farmer Produce Marketing - API Client
const API_BASE = '/api';

const API = {
  getToken() {
    return localStorage.getItem('agri_jwt_token') || null;
  },

  setToken(token) {
    if (token) {
      localStorage.setItem('agri_jwt_token', token);
    } else {
      localStorage.removeItem('agri_jwt_token');
    }
  },

  getCurrentUser() {
    try {
      const u = localStorage.getItem('agri_user');
      return u ? JSON.parse(u) : null;
    } catch (e) {
      return null;
    }
  },

  setCurrentUser(user) {
    if (user) {
      localStorage.setItem('agri_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('agri_user');
    }
  },

  logout() {
    this.setToken(null);
    this.setCurrentUser(null);
    window.location.hash = '#marketplace';
    window.location.reload();
  },

  async request(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const headers = options.headers || {};

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    if (!(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }

    const config = {
      ...options,
      headers
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || `Request failed with status ${response.status}`);
      }

      return data;
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      throw err;
    }
  },

  // Auth Endpoints
  async login(email, password) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    if (data.token) this.setToken(data.token);
    if (data.user) this.setCurrentUser(data.user);
    return data;
  },

  async register(formData) {
    const data = await this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(formData)
    });
    if (data.token) this.setToken(data.token);
    if (data.user) this.setCurrentUser(data.user);
    return data;
  },

  async getMe() {
    const data = await this.request('/auth/me');
    if (data.user) this.setCurrentUser(data.user);
    return data.user;
  },

  async updateProfile(profileData) {
    const data = await this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData)
    });
    if (data.user) this.setCurrentUser(data.user);
    return data;
  },

  // Products Endpoints
  async getProducts(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return await this.request(`/products?${qs}`);
  },

  async getProduct(id) {
    return await this.request(`/products/${id}`);
  },

  async createProduct(formData) {
    return await this.request('/products', {
      method: 'POST',
      body: formData
    });
  },

  async updateProduct(id, formData) {
    return await this.request(`/products/${id}`, {
      method: 'PUT',
      body: formData
    });
  },

  async deleteProduct(id) {
    return await this.request(`/products/${id}`, {
      method: 'DELETE'
    });
  },

  // Orders Endpoints
  async createOrder(orderPayload) {
    return await this.request('/orders', {
      method: 'POST',
      body: JSON.stringify(orderPayload)
    });
  },

  async getOrders() {
    return await this.request('/orders');
  },

  async getOrder(id) {
    return await this.request(`/orders/${id}`);
  },

  async farmerOrderAction(id, action, note) {
    return await this.request(`/orders/${id}/farmer-action`, {
      method: 'PUT',
      body: JSON.stringify({ action, note })
    });
  },

  // Admin Endpoints
  async getAdminDashboard() {
    return await this.request('/admin/dashboard');
  },

  async getAdminUsers(role) {
    const qs = role ? `?role=${role}` : '';
    return await this.request(`/admin/users${qs}`);
  },

  async deleteUser(id) {
    return await this.request(`/admin/users/${id}`, {
      method: 'DELETE'
    });
  },

  async getLogisticsOptions() {
    return await this.request('/admin/logistics-options');
  },

  async assignLogistics(id, data) {
    return await this.request(`/admin/orders/${id}/logistics`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  },

  async updateOrderStatus(id, data) {
    return await this.request(`/admin/orders/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  },

  async getReports() {
    return await this.request('/admin/reports');
  },

  // AWS Simulation Endpoints
  async getAwsTelemetry() {
    return await this.request('/aws/telemetry');
  },

  async simulateSnsNotification(data) {
    return await this.request('/aws/simulate-sns', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }
};
