﻿// Farmer Produce Marketing - Main App Coordinator & Router
const App = {
  currentView: 'marketplace',

  init() {
    State.init();
    Marketplace.init();
    AwsSim.init();

    this.bindEvents();
    this.updateUserNav();

    // Check hash on load
    window.addEventListener('hashchange', () => this.handleRouting());
    this.handleRouting();
  },

  bindEvents() {
    // Nav links
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        const hash = link.getAttribute('href');
        if (hash && hash.startsWith('#')) {
          e.preventDefault();
          window.location.hash = hash;
        }
      });
    });

    // Close modals when clicking overlay outside modal-content
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('show');
        }
      });
    });

    // Keyboard ESC to close any modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.show').forEach(m => m.classList.remove('show'));
      }
    });

    // Auth forms
    const loginForm = document.getElementById('login-form');
    if (loginForm) loginForm.addEventListener('submit', (e) => this.handleLogin(e));

    const registerForm = document.getElementById('register-form');
    if (registerForm) registerForm.addEventListener('submit', (e) => this.handleRegister(e));

    // Farmer produce form
    const prodForm = document.getElementById('product-form');
    if (prodForm) prodForm.addEventListener('submit', (e) => Farmer.handleProductFormSubmit(e));

    // Admin logistics form
    const adminLogisticsForm = document.getElementById('admin-logistics-form');
    if (adminLogisticsForm) adminLogisticsForm.addEventListener('submit', (e) => Admin.handleLogisticsSubmit(e));

    // Admin status form
    const adminStatusForm = document.getElementById('admin-status-form');
    if (adminStatusForm) adminStatusForm.addEventListener('submit', (e) => Admin.handleStatusSubmit(e));

    // Checkout form
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) checkoutForm.addEventListener('submit', (e) => Marketplace.processCheckout(e));

    // Register Role toggle (show/hide farm name input)
    const roleSelect = document.getElementById('reg-role');
    if (roleSelect) {
      roleSelect.addEventListener('change', (e) => {
        const farmGroup = document.getElementById('reg-farm-group');
        if (farmGroup) {
          farmGroup.style.display = e.target.value === 'farmer' ? 'block' : 'none';
        }
      });
    }

    // Payment method selector buttons
    document.querySelectorAll('.payment-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.payment-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const method = btn.dataset.method;
        const upiBox = document.getElementById('pay-upi-box');
        const cardBox = document.getElementById('pay-card-box');
        if (upiBox) upiBox.style.display = method === 'UPI' ? 'block' : 'none';
        if (cardBox) cardBox.style.display = method === 'CARD' ? 'block' : 'none';
      });
    });
  },

  handleRouting() {
    let hash = window.location.hash.replace('#', '') || 'marketplace';
    const allowed = ['marketplace', 'farmer', 'admin', 'aws', 'orders'];
    if (!allowed.includes(hash)) {
      hash = 'marketplace';
    }
    this.navigate(hash);
  },

  navigate(viewName) {
    this.currentView = viewName;

    // Guard routes
    if (viewName === 'farmer') {
      if (!State.currentUser || (State.currentUser.role !== 'farmer' && State.currentUser.role !== 'admin')) {
        Toast.show('Please log in with a Farmer account to access the Farmer Dashboard.', 'error');
        this.showAuthModal('login');
        window.location.hash = '#marketplace';
        return;
      }
      Farmer.init();
    } else if (viewName === 'admin') {
      if (!State.currentUser || State.currentUser.role !== 'admin') {
        Toast.show('Access Restricted. Directorate Administrator credentials required.', 'error');
        this.showAuthModal('login');
        window.location.hash = '#marketplace';
        return;
      }
      Admin.init();
    } else if (viewName === 'orders') {
      if (!State.currentUser) {
        Toast.show('Please log in to view your orders.', 'error');
        this.showAuthModal('login');
        window.location.hash = '#marketplace';
        return;
      }
      this.loadCustomerOrders();
    } else if (viewName === 'aws') {
      AwsSim.fetchTelemetry();
    }

    // Toggle View Panels
    document.querySelectorAll('.view-panel').forEach(panel => {
      panel.classList.remove('active');
    });

    const activePanel = document.getElementById(`view-${viewName}`);
    if (activePanel) {
      activePanel.classList.add('active');
    }

    // Update Nav Link Active class
    document.querySelectorAll('.nav-link').forEach(link => {
      const href = link.getAttribute('href');
      link.classList.toggle('active', href === `#${viewName}`);
    });

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  updateUserNav() {
    const user = State.currentUser;
    const guestNav = document.getElementById('nav-guest-actions');
    const userNav = document.getElementById('nav-user-actions');
    const userNameEl = document.getElementById('nav-user-name');
    const userRoleEl = document.getElementById('nav-user-role');
    const farmerLink = document.getElementById('nav-link-farmer');
    const adminLink = document.getElementById('nav-link-admin');
    const ordersLink = document.getElementById('nav-link-orders');

    if (user) {
      if (guestNav) guestNav.style.display = 'none';
      if (userNav) userNav.style.display = 'flex';
      if (userNameEl) userNameEl.textContent = user.name;
      if (userRoleEl) {
        let roleName = 'Customer';
        if (user.role === 'farmer') roleName = 'Farmer Partner';
        if (user.role === 'admin') roleName = 'State Admin';
        userRoleEl.textContent = roleName;
      }

      if (farmerLink) farmerLink.style.display = (user.role === 'farmer' || user.role === 'admin') ? 'inline-block' : 'none';
      if (adminLink) adminLink.style.display = (user.role === 'admin') ? 'inline-block' : 'none';
      if (ordersLink) ordersLink.style.display = 'inline-block';
    } else {
      if (guestNav) guestNav.style.display = 'flex';
      if (userNav) userNav.style.display = 'none';
      if (farmerLink) farmerLink.style.display = 'none';
      if (adminLink) adminLink.style.display = 'none';
      if (ordersLink) ordersLink.style.display = 'none';
    }

    State.updateCartBadge();
  },

  // Modal Controllers
  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('show');
    }
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('show');
    }
  },

  showAuthModal(tab = 'login', msg = '') {
    this.switchAuthTab(tab);
    const msgEl = document.getElementById('auth-modal-msg');
    if (msgEl) {
      msgEl.textContent = msg;
      msgEl.style.display = msg ? 'block' : 'none';
    }
    this.openModal('auth-modal');
  },

  switchAuthTab(tab) {
    const isLogin = tab === 'login';
    const loginSection = document.getElementById('auth-section-login');
    const regSection = document.getElementById('auth-section-register');
    const tabLogin = document.getElementById('auth-tab-btn-login');
    const tabReg = document.getElementById('auth-tab-btn-register');

    if (loginSection) loginSection.style.display = isLogin ? 'block' : 'none';
    if (regSection) regSection.style.display = isLogin ? 'none' : 'block';
    if (tabLogin) tabLogin.classList.toggle('active', isLogin);
    if (tabReg) tabReg.classList.toggle('active', !isLogin);
  },

  // Authentication Handlers
  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const btn = document.getElementById('btn-login-submit');

    if (!email || !password) {
      Toast.show('Please enter both email and password.', 'error');
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Verifying credentials...';
    }

    try {
      const res = await API.login(email, password);
      State.currentUser = res.user;
      this.updateUserNav();
      this.closeModal('auth-modal');
      Toast.show(`Welcome back, ${res.user.name}! [Role: ${res.user.role.toUpperCase()}]`, 'success');

      if (res.user.role === 'farmer') {
        window.location.hash = '#farmer';
      } else if (res.user.role === 'admin') {
        window.location.hash = '#admin';
      } else {
        window.location.hash = '#marketplace';
      }
    } catch (err) {
      Toast.show(err.message || 'Login failed. Please check credentials.', 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Log In to Platform';
      }
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const phone = document.getElementById('reg-phone').value.trim();
    const role = document.getElementById('reg-role').value;
    const farmName = document.getElementById('reg-farm-name').value.trim();
    const address = document.getElementById('reg-address').value.trim();
    const district = document.getElementById('reg-district').value;
    const pincode = document.getElementById('reg-pincode').value.trim();
    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm-password').value;

    if (!name || !email || !phone || !address || !district || !pincode || !password) {
      Toast.show('Please fill in all required registration fields.', 'error');
      return;
    }

    if (password !== confirmPassword) {
      Toast.show('Passwords do not match.', 'error');
      return;
    }

    const payload = {
      name,
      email,
      phone,
      role,
      farmName: role === 'farmer' ? farmName : undefined,
      address,
      district,
      state: 'Tamil Nadu',
      pincode,
      password,
      confirmPassword
    };

    try {
      const res = await API.register(payload);
      State.currentUser = res.user;
      this.updateUserNav();
      this.closeModal('auth-modal');
      Toast.show(`Account created successfully! Welcome, ${res.user.name}.`, 'success');

      if (role === 'farmer') {
        window.location.hash = '#farmer';
      } else {
        window.location.hash = '#marketplace';
      }
    } catch (err) {
      Toast.show(err.message || 'Registration failed.', 'error');
    }
  },

  // One-Click Demo Logins for Evaluation
  async demoLogin(role) {
    const creds = {
      admin: { email: 'admin@agri.gov.in', pass: 'Admin@123' },
      farmer: { email: 'selvam@farmer.tn.in', pass: 'Farmer@123' },
      customer: { email: 'anand@customer.tn.in', pass: 'Customer@123' }
    };

    const target = creds[role];
    if (!target) return;

    try {
      const res = await API.login(target.email, target.pass);
      State.currentUser = res.user;
      this.updateUserNav();
      this.closeModal('auth-modal');
      Toast.show(`⚡ Switched to Demo Account: ${res.user.name} (${res.user.role.toUpperCase()})`, 'aws', 3000);

      if (res.user.role === 'admin') {
        window.location.hash = '#admin';
      } else if (res.user.role === 'farmer') {
        window.location.hash = '#farmer';
      } else {
        window.location.hash = '#marketplace';
      }
    } catch (err) {
      Toast.show('Demo login failed: ' + err.message, 'error');
    }
  },

  logout() {
    API.logout();
  },

  // Order Tracking View
  async showOrderTracking(orderId) {
    try {
      const res = await API.getOrder(orderId);
      if (!res.success || !res.order) {
        Toast.show('Order tracking data not found.', 'error');
        return;
      }

      const order = res.order;
      document.getElementById('track-order-id').textContent = order.id;
      document.getElementById('track-customer-name').textContent = order.customerName;
      document.getElementById('track-delivery-dest').textContent = `${order.deliveryAddress?.district}, Tamil Nadu (Pincode: ${order.deliveryAddress?.pincode})`;

      // Logistics routes
      document.getElementById('track-centre-name').textContent = order.logistics?.collectionCentre || 'Madurai Agro Collection Centre';
      document.getElementById('track-hub-name').textContent = order.logistics?.districtHub || 'Chennai Central Agro Logistics Hub';
      document.getElementById('track-delivery-agent').textContent = order.logistics?.deliveryPerson || 'Ravi Kumar (SpeedAgri Logistics - +91 9876543210)';

      // Timeline entries
      const timelineContainer = document.getElementById('track-timeline-list');
      if (timelineContainer && order.logistics?.timeline) {
        timelineContainer.innerHTML = order.logistics.timeline.map((item, idx) => {
          const isLatest = idx === order.logistics.timeline.length - 1;
          const timeStr = new Date(item.timestamp).toLocaleString('en-IN', {
            dateStyle: 'medium',
            timeStyle: 'short'
          });

          return `
            <div class="timeline-item">
              <div class="timeline-point ${isLatest ? 'active' : ''}"></div>
              <div class="timeline-content">
                <div class="timeline-header">
                  <span class="timeline-title">${item.title}</span>
                  <span class="timeline-time">${timeStr}</span>
                </div>
                <div class="timeline-loc">📍 ${item.location}</div>
                <div class="timeline-note">${item.note}</div>
              </div>
            </div>
          `;
        }).join('');
      }

      this.openModal('tracking-modal');
    } catch (err) {
      console.error('Tracking load error:', err);
      Toast.show('Failed to load tracking timeline.', 'error');
    }
  },

  // Customer Orders List
  async loadCustomerOrders() {
    const listEl = document.getElementById('customer-orders-list');
    if (!listEl) return;

    listEl.innerHTML = `
      <div style="text-align:center; padding:2.5rem; color:var(--slate-500);">
        Loading your fresh farm produce orders...
      </div>
    `;

    try {
      const res = await API.getOrders();
      const orders = res.orders || [];

      if (orders.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-icon">📦</div>
            <h3 class="empty-title">No orders placed yet</h3>
            <p class="empty-desc">You haven't ordered direct produce from Tamil Nadu farmers yet.</p>
            <button class="btn btn-primary" style="margin-top:1rem;" onclick="window.location.hash='#marketplace'">Browse Fresh Produce</button>
          </div>
        `;
        return;
      }

      listEl.innerHTML = orders.map(order => {
        let badgeClass = 'badge-placed';
        if (order.orderStatus === 'FARMER_CONFIRMED') badgeClass = 'badge-confirmed';
        if (order.orderStatus.includes('TRANSIT') || order.orderStatus.includes('COLLECTION') || order.orderStatus.includes('HUB') || order.orderStatus.includes('DELIVERY')) badgeClass = 'badge-transit';
        if (order.orderStatus === 'DELIVERED') badgeClass = 'badge-delivered';
        if (order.orderStatus === 'CANCELLED') badgeClass = 'badge-cancelled';

        const itemsSummary = order.items.map(i => `
          <div style="display:flex; justify-content:space-between; font-size:0.85rem; padding:0.35rem 0; border-bottom:1px solid var(--slate-100);">
            <span>${i.name} (×${i.quantity} ${i.unit})</span>
            <strong style="color:var(--slate-800);">₹${i.price * i.quantity}</strong>
          </div>
        `).join('');

        return `
          <div class="table-card" style="margin-bottom:1.5rem; padding:1.25rem;">
            <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:0.5rem; margin-bottom:1rem; border-bottom:1px solid var(--slate-200); padding-bottom:0.75rem;">
              <div>
                <strong style="font-size:1.1rem; color:var(--primary); font-family:monospace;">#${order.id}</strong>
                <span style="font-size:0.8rem; color:var(--slate-400); margin-left:0.5rem;">${new Date(order.createdAt).toLocaleDateString()}</span>
              </div>
              <div style="display:flex; align-items:center; gap:0.6rem;">
                <span class="badge ${badgeClass}">${order.orderStatus.replace(/_/g, ' ')}</span>
                <button class="btn btn-primary btn-sm" onclick="App.showOrderTracking('${order.id}')">
                  📍 Live Tracking
                </button>
              </div>
            </div>

            <div style="margin-bottom:1rem;">
              ${itemsSummary}
            </div>

            <div style="display:flex; align-items:center; justify-content:space-between; background:var(--slate-50); padding:0.75rem 1rem; border-radius:var(--radius-md); font-size:0.9rem;">
              <div>
                <span style="color:var(--slate-500); font-size:0.8rem;">Delivery To:</span><br>
                <strong>${order.deliveryAddress?.street}, ${order.deliveryAddress?.district}</strong>
              </div>
              <div style="text-align:right;">
                <span style="color:var(--slate-500); font-size:0.8rem;">Total Paid:</span><br>
                <strong style="font-size:1.15rem; color:var(--slate-900);">₹${order.total}</strong>
              </div>
            </div>
          </div>
        `;
      }).join('');
    } catch (err) {
      listEl.innerHTML = `<div style="color:var(--danger); padding:1rem;">Failed to load orders: ${err.message}</div>`;
    }
  },

  openCart() {
    Marketplace.renderCart();
    this.openModal('cart-modal');
  }
};

// Start application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
