﻿// Farmer Produce Marketing - AWS Cloud Architecture Simulator Controller
const AwsSim = {
  telemetryTimer: null,
  isPolling: false,

  async init() {
    this.bindEvents();
    await this.fetchTelemetry();
    this.startPolling();
  },

  bindEvents() {
    const form = document.getElementById('aws-sns-form');
    if (form) {
      form.addEventListener('submit', (e) => this.handleSimulateSns(e));
    }
  },

  startPolling() {
    if (this.telemetryTimer) clearInterval(this.telemetryTimer);
    this.telemetryTimer = setInterval(() => {
      // Only poll when AWS view is active
      const awsView = document.getElementById('view-aws');
      if (awsView && awsView.classList.contains('active')) {
        this.fetchTelemetry(true);
      }
    }, 4500);
  },

  stopPolling() {
    if (this.telemetryTimer) {
      clearInterval(this.telemetryTimer);
      this.telemetryTimer = null;
    }
  },

  async fetchTelemetry(isBackground = false) {
    try {
      const res = await API.getAwsTelemetry();
      if (res.success) {
        this.renderMetrics(res.metrics || {}, res.architecture || {});
        if (!isBackground) {
          Toast.show('AWS Cloud Telemetry synchronized with ap-south-1 (Mumbai)', 'aws', 2200);
        }
      }
    } catch (err) {
      console.error('AWS telemetry fetch error:', err);
    }
  },

  renderMetrics(m, arch) {
    // 1. EC2 & App Runner
    const ec2 = m.ec2 || {};
    const setEl = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text;
    };

    setEl('aws-ec2-id', ec2.instanceId || 'i-0a89d71c42b109e');
    setEl('aws-ec2-type', ec2.instanceType || 't3.medium');
    setEl('aws-ec2-cpu', `${ec2.cpuUtilizationPercent || 18.4}%`);
    setEl('aws-ec2-mem', `${ec2.memoryUsagePercent || 42.1}%`);
    setEl('aws-ec2-reqs', (ec2.totalRequestsHandled || 12480).toLocaleString());

    // 2. Amazon S3
    const s3 = m.s3 || {};
    setEl('aws-s3-bucket', s3.bucketName || 's3://tn-farmer-produce-marketing-prod');
    setEl('aws-s3-objects', s3.totalObjects || 48);
    const sizeMb = ((s3.storageSizeBytes || 24890120) / (1024 * 1024)).toFixed(2);
    setEl('aws-s3-size', `${sizeMb} MB`);
    setEl('aws-s3-encryption', s3.encryption || 'AWS-KMS (aws/s3)');

    // 3. Amazon DynamoDB
    const ddb = m.dynamoDb || {};
    const ddbContainer = document.getElementById('aws-ddb-tables');
    if (ddbContainer && ddb.tables) {
      ddbContainer.innerHTML = ddb.tables.map(t => `
        <div style="display:flex; align-items:center; justify-content:space-between; padding:0.4rem 0; border-bottom:1px solid #1f2c42; font-size:0.78rem;">
          <div>
            <strong style="color:#f8fafc; font-family:monospace;">${t.name}</strong>
            <span style="color:#64748b; margin-left:0.5rem;">[${t.readCapacityUnits} RCU / ${t.writeCapacityUnits} WCU]</span>
          </div>
          <div style="display:flex; align-items:center; gap:0.5rem;">
            <span style="color:#ff9900; font-weight:700;">${t.itemCount} items</span>
            <span style="color:#10b981; font-size:0.7rem; font-weight:800;">ACTIVE</span>
          </div>
        </div>
      `).join('');
    }

    // 4. Amazon SNS
    const sns = m.sns || {};
    setEl('aws-sns-total', sns.totalNotificationsSent || 0);
    setEl('aws-sns-arn', sns.topicArn || 'arn:aws:sns:ap-south-1:892019482012:TN_FarmerProduceAlerts');

    const snsFeed = document.getElementById('aws-sns-feed');
    if (snsFeed && sns.recentDispatches) {
      snsFeed.innerHTML = sns.recentDispatches.slice(0, 4).map(d => `
        <div style="background:#151e2e; border:1px solid #233148; border-radius:var(--radius-md); padding:0.6rem 0.75rem; margin-bottom:0.5rem; font-size:0.75rem;">
          <div style="display:flex; justify-content:space-between; color:#ff9900; font-weight:700; margin-bottom:0.2rem;">
            <span>[${d.type}] ${d.recipient}</span>
            <span style="color:#10b981;">DELIVERED</span>
          </div>
          <div style="color:#cbd5e1; font-family:monospace; line-height:1.3;">"${d.message}"</div>
          <div style="color:#64748b; font-size:0.7rem; margin-top:0.25rem;">${new Date(d.timestamp).toLocaleTimeString()}</div>
        </div>
      `).join('');
    }

    // 5. Amazon CloudWatch Logs & Metrics
    const cw = m.cloudWatch || {};
    setEl('aws-cw-latency', `${cw.p95LatencyMs || 42} ms`);
    setEl('aws-cw-error', `${cw.errorRatePercent || 0.02}%`);
    setEl('aws-cw-status', cw.alarmStatus || 'OK');

    const logBox = document.getElementById('aws-cloudwatch-logs');
    if (logBox && cw.recentLogs) {
      logBox.innerHTML = cw.recentLogs.map(l => {
        let levelColor = '#10b981';
        if (l.level === 'WARN') levelColor = '#f59e0b';
        if (l.level === 'ERROR') levelColor = '#ef4444';

        const timeStr = new Date(l.timestamp).toLocaleTimeString();
        return `
          <div class="log-entry">
            <span class="log-time">[${timeStr}]</span>
            <span style="color:${levelColor}; font-weight:700;">[${l.level}]</span>
            <span class="log-service">[${l.service}]</span>
            <span class="log-msg">${l.message}</span>
          </div>
        `;
      }).join('');
    }
  },

  async handleSimulateSns(e) {
    e.preventDefault();
    const type = document.getElementById('sns-sim-type').value;
    const recipient = document.getElementById('sns-sim-recipient').value.trim();
    const message = document.getElementById('sns-sim-message').value.trim();

    if (!recipient || !message) {
      Toast.show('Please provide recipient details and message text.', 'error');
      return;
    }

    const btn = document.getElementById('btn-send-sns');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Publishing to AWS SNS...';
    }

    try {
      const res = await API.simulateSnsNotification({ type, recipient, message });
      Toast.show(`Amazon SNS Alert Published! Dispatched via AWS SMS Gateway.`, 'aws');
      document.getElementById('sns-sim-message').value = '';
      await this.fetchTelemetry(true);
    } catch (err) {
      Toast.show(err.message || 'Failed to simulate SNS message.', 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Publish SNS Notification';
      }
    }
  }
};
