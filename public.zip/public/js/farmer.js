// Farmer Produce Marketing - Farmer Dashboard Controller
const Farmer = {
  farmerProducts: [],
  farmerOrders: [],

  async init() {
    if (!State.currentUser || (State.currentUser.role !== 'farmer' && State.currentUser.role !== 'admin')) {
      Toast.show('Please log in with a Farmer account to access this portal.', 'error');
      App.showAuthModal('login');
      return;
    }
    await this.loadDashboardData();
  },

  async loadDashboardData() {
    const user = State.currentUser;
    const welcomeEl = document.getElementById('farmer-welcome-name');
    if (welcomeEl) {
      welcomeEl.textContent = `Welcome, Farmer ${user.name} (${user.farmName || user.district + ' Agro Belt'})`;
    }

    try {
      // Load products listed by this farmer
      const prodRes = await API.getProducts({ farmerId: user.id });
      this.farmerProducts = prodRes.products || [];

      // Load orders
      const orderRes = await API.getOrders();
      this.farmerOrders = orderRes.orders || [];

      this.renderKPIs();
      this.renderProductsTable();
      this.renderOrdersTable();
    } catch (err) {
      console.error('Farmer load error:', err);
      Toast.show('Failed to refresh farmer dashboard data.', 'error');
    }
  },

  renderKPIs() {
    const totalProds = this.farmerProducts.length;
    const totalAvailQty = this.farmerProducts.reduce((sum, p) => sum + (p.availableQuantity || 0), 0);
    const totalOrdersCount = this.farmerOrders.length;
    const completedOrders = this.farmerOrders.filter(o => o.orderStatus === 'DELIVERED').length;
    const pendingOrders = this.farmerOrders.filter(o => o.orderStatus !== 'DELIVERED' && o.orderStatus !== 'CANCELLED').length;

    // Calculate revenue for this farmer's items
    let totalSalesVal = 0;
    this.farmerOrders.forEach(o => {
      if (o.orderStatus !== 'CANCELLED') {
        (o.items || []).forEach(item => {
          if (item.farmerId === State.currentUser.id || State.currentUser.role === 'admin') {
            totalSalesVal += (item.price * item.quantity);
          }
        });
      }
    });

    const elTotalProds = document.getElementById('kpi-farmer-products');
    const elAvailQty = document.getElementById('kpi-farmer-qty');
    const elOrders = document.getElementById('kpi-farmer-orders');
    const elPending = document.getElementById('kpi-farmer-pending');
    const elSales = document.getElementById('kpi-farmer-sales');

    if (elTotalProds) elTotalProds.textContent = totalProds;
    if (elAvailQty) elAvailQty.textContent = `${totalAvailQty} units`;
    if (elOrders) elOrders.textContent = totalOrdersCount;
    if (elPending) elPending.textContent = pendingOrders;
    if (elSales) elSales.textContent = `₹${totalSalesVal.toLocaleString()}`;
  },

  renderProductsTable() {
    const tbody = document.getElementById('farmer-products-tbody');
    if (!tbody) return;

    if (this.farmerProducts.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align:center; padding:2rem; color:var(--slate-500);">
            🌾 You have not listed any agricultural crops yet. Click "Add New Produce" to get started!
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = this.farmerProducts.map(prod => `
      <tr>
        <td>
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <img src="${prod.image || '/assets/products/ponni_rice.jpg'}" alt="${prod.name}" style="width:45px; height:45px; border-radius:var(--radius-md); object-fit:cover;">
            <div>
              <strong style="color:var(--slate-900); font-size:0.92rem;">${prod.name}</strong>
              <div style="font-size:0.75rem; color:var(--slate-500);">Cat: ${prod.category} • Harvest: ${prod.harvestDate || 'N/A'}</div>
            </div>
          </div>
        </td>
        <td><strong style="color:var(--primary);">₹${prod.price}</strong> / ${prod.unit}</td>
        <td>
          <span class="badge ${prod.availableQuantity > 0 ? 'badge-confirmed' : 'badge-cancelled'}">
            ${prod.availableQuantity} ${prod.unit}
          </span>
        </td>
        <td>📍 ${prod.location || prod.district}</td>
        <td><span style="font-size:0.78rem; font-weight:700; color:var(--slate-600);">${prod.organicCertification || 'Farmer Verified'}</span></td>
        <td>
          <div style="display:flex; gap:0.4rem;">
            <button class="btn btn-secondary btn-sm" onclick="Farmer.openEditProductModal('${prod.id}')" title="Edit Produce">✏️ Edit</button>
            <button class="btn btn-danger btn-sm" onclick="Farmer.deleteProduct('${prod.id}')" title="Delete Produce">🗑️</button>
          </div>
        </td>
      </tr>
    `).join('');
  },

  renderOrdersTable() {
    const tbody = document.getElementById('farmer-orders-tbody');
    if (!tbody) return;

    if (this.farmerOrders.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align:center; padding:2rem; color:var(--slate-500);">
            📦 No incoming customer orders right now. Orders placed by customers will appear here instantly.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = this.farmerOrders.map(order => {
      // Status badge mapping
      let badgeClass = 'badge-placed';
      if (order.orderStatus === 'FARMER_CONFIRMED') badgeClass = 'badge-confirmed';
      if (order.orderStatus.includes('TRANSIT') || order.orderStatus.includes('COLLECTION') || order.orderStatus.includes('HUB') || order.orderStatus.includes('DELIVERY')) badgeClass = 'badge-transit';
      if (order.orderStatus === 'DELIVERED') badgeClass = 'badge-delivered';
      if (order.orderStatus === 'CANCELLED') badgeClass = 'badge-cancelled';

      const itemsDesc = order.items.map(i => `${i.name} (${i.quantity} ${i.unit})`).join(', ');

      return `
        <tr>
          <td><strong style="color:var(--primary); font-family:monospace;">#${order.id}</strong></td>
          <td>
            <div style="font-weight:700; color:var(--slate-800);">${order.customerName}</div>
            <div style="font-size:0.75rem; color:var(--slate-500);">📞 ${order.customerPhone} • ${order.deliveryAddress?.district}</div>
          </td>
          <td style="max-width:240px; font-size:0.85rem;">${itemsDesc}</td>
          <td><strong style="color:var(--slate-900);">₹${order.total}</strong></td>
          <td><span class="badge ${badgeClass}">${order.orderStatus.replace(/_/g, ' ')}</span></td>
          <td>
            <span class="badge badge-paid">${order.payment?.status || 'PAID'} (${order.payment?.method || 'UPI'})</span>
          </td>
          <td>
            <div style="display:flex; gap:0.4rem; flex-wrap:wrap;">
              ${order.orderStatus === 'PLACED' ? `
                <button class="btn btn-primary btn-sm" onclick="Farmer.handleOrderAction('${order.id}', 'accept')">Accept</button>
                <button class="btn btn-danger btn-sm" onclick="Farmer.handleOrderAction('${order.id}', 'reject')">Reject</button>
              ` : ''}

              ${order.orderStatus === 'FARMER_CONFIRMED' ? `
                <button class="btn btn-accent btn-sm" onclick="Farmer.handleOrderAction('${order.id}', 'dispatch')">
                  🚚 Dispatch to Collection Hub
                </button>
              ` : ''}

              <button class="btn btn-secondary btn-sm" onclick="App.showOrderTracking('${order.id}')">
                📍 Track
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  async handleOrderAction(orderId, action) {
    let promptMsg = 'Add notes for the logistics dispatch centre (Optional):';
    if (action === 'reject') promptMsg = 'Reason for rejection (Optional):';
    const note = prompt(promptMsg, action === 'dispatch' ? 'Dispatched to Village Collection Centre via Agro Mini-Truck' : 'Produce verified & packaged');

    try {
      await API.farmerOrderAction(orderId, action, note);
      Toast.show(`Order #${orderId} marked as ${action.toUpperCase()}`, 'success');
      await this.loadDashboardData();
    } catch (err) {
      Toast.show(err.message || 'Action failed.', 'error');
    }
  },

  openAddProductModal() {
    const form = document.getElementById('product-form');
    if (form) form.reset();
    document.getElementById('product-modal-title').textContent = 'List New Farm Produce';
    document.getElementById('product-edit-id').value = '';
    App.openModal('product-form-modal');
  },

  openEditProductModal(productId) {
    const prod = this.farmerProducts.find(p => p.id === productId);
    if (!prod) return;

    document.getElementById('product-modal-title').textContent = 'Edit Farm Produce Listing';
    document.getElementById('product-edit-id').value = prod.id;
    document.getElementById('prod-input-name').value = prod.name;
    document.getElementById('prod-input-category').value = prod.category;
    document.getElementById('prod-input-price').value = prod.price;
    document.getElementById('prod-input-unit').value = prod.unit;
    document.getElementById('prod-input-qty').value = prod.availableQuantity;
    document.getElementById('prod-input-location').value = prod.location;
    document.getElementById('prod-input-cert').value = prod.organicCertification || '';
    document.getElementById('prod-input-desc').value = prod.description || '';

    App.openModal('product-form-modal');
  },

  async handleProductFormSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('product-edit-id').value;
    const name = document.getElementById('prod-input-name').value.trim();
    const category = document.getElementById('prod-input-category').value;
    const price = document.getElementById('prod-input-price').value;
    const unit = document.getElementById('prod-input-unit').value;
    const availableQuantity = document.getElementById('prod-input-qty').value;
    const location = document.getElementById('prod-input-location').value.trim();
    const organicCertification = document.getElementById('prod-input-cert').value.trim();
    const description = document.getElementById('prod-input-desc').value.trim();
    const fileInput = document.getElementById('prod-input-file');

    if (!name || !price || !availableQuantity) {
      Toast.show('Please fill in produce name, price and available stock.', 'error');
      return;
    }

    const formData = new FormData();
    formData.append('name', name);
    formData.append('category', category);
    formData.append('price', price);
    formData.append('unit', unit);
    formData.append('availableQuantity', availableQuantity);
    formData.append('location', location);
    formData.append('organicCertification', organicCertification);
    formData.append('description', description);

    if (fileInput && fileInput.files[0]) {
      formData.append('image', fileInput.files[0]);
    }

    try {
      if (id) {
        await API.updateProduct(id, formData);
        Toast.show(`Produce "${name}" updated successfully!`, 'success');
      } else {
        await API.createProduct(formData);
        Toast.show(`Produce "${name}" listed on Marketplace! [AWS S3 synced]`, 'success');
      }

      App.closeModal('product-form-modal');
      await this.loadDashboardData();
      await Marketplace.loadProducts();
    } catch (err) {
      Toast.show(err.message || 'Failed to save product.', 'error');
    }
  },

  async deleteProduct(productId) {
    if (!confirm('Are you sure you want to remove this farm produce listing from the marketplace?')) {
      return;
    }

    try {
      await API.deleteProduct(productId);
      Toast.show('Product listing deleted.', 'info');
      await this.loadDashboardData();
      await Marketplace.loadProducts();
    } catch (err) {
      Toast.show(err.message || 'Failed to delete product.', 'error');
    }
  }
};
