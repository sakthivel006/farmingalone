// Farmer Produce Marketing - Marketplace & Cart Controller
const Marketplace = {
  async init() {
    this.bindEvents();
    await this.loadProducts();
  },

  bindEvents() {
    // Search input with debounce
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
      let timeout;
      searchInput.addEventListener('input', (e) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
          State.filters.search = e.target.value;
          this.loadProducts();
        }, 300);
      });
    }

    // District filter
    const districtSelect = document.getElementById('district-filter');
    if (districtSelect) {
      districtSelect.addEventListener('change', (e) => {
        State.filters.district = e.target.value;
        this.loadProducts();
      });
    }

    // Sort filter
    const sortSelect = document.getElementById('sort-filter');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        State.filters.sort = e.target.value;
        this.loadProducts();
      });
    }

    // Category pills
    const pills = document.querySelectorAll('.category-pill');
    pills.forEach(pill => {
      pill.addEventListener('click', (e) => {
        pills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        State.filters.category = pill.dataset.category;
        this.loadProducts();
      });
    });
  },

  async loadProducts() {
    const grid = document.getElementById('products-grid');
    if (!grid) return;

    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 3rem;">
        <div style="font-size: 1.5rem; color: var(--primary); font-weight: 700; margin-bottom: 0.5rem;">🌱 Harvesting Fresh Data...</div>
        <p style="color: var(--slate-500);">Fetching direct agricultural produce listings across Tamil Nadu...</p>
      </div>
    `;

    try {
      const params = {};
      if (State.filters.search) params.search = State.filters.search;
      if (State.filters.category && State.filters.category !== 'All') params.category = State.filters.category;
      if (State.filters.district && State.filters.district !== 'All') params.district = State.filters.district;
      if (State.filters.sort) params.sort = State.filters.sort;

      const res = await API.getProducts(params);
      State.products = res.products || [];
      this.renderProducts(State.products);
    } catch (err) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <h3 class="empty-title">Could not load produce listings</h3>
          <p class="empty-desc">${err.message || 'Please verify the backend server connection.'}</p>
          <button class="btn btn-primary" style="margin-top:1rem;" onclick="Marketplace.loadProducts()">Retry</button>
        </div>
      `;
    }
  },

  renderProducts(products) {
    const grid = document.getElementById('products-grid');
    if (!grid) return;

    if (!products || products.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🌾</div>
          <h3 class="empty-title">No agricultural produce found</h3>
          <p class="empty-desc">No produce matches the selected filters. Try choosing a different Tamil Nadu district or category.</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = products.map(prod => `
      <div class="product-card" id="card-${prod.id}">
        <div class="card-img-wrap">
          <img src="${prod.image || '/assets/products/ponni_rice.jpg'}" alt="${prod.name}" class="card-img" onerror="this.src='/assets/hero_agri_banner.jpg'">
          <span class="card-tag">${prod.category}</span>
          <span class="card-district">📍 ${prod.district}</span>
        </div>
        <div class="card-body">
          <div class="card-farmer-info">
            <span>👨‍🌾</span>
            <strong style="color:var(--slate-800);">${prod.farmerName}</strong>
          </div>
          <h3 class="card-title">${prod.name}</h3>
          <p class="card-desc">${prod.description}</p>
          
          <div style="margin-bottom: 0.75rem; display: flex; align-items:center; gap:0.4rem; font-size:0.75rem; color:var(--primary); font-weight:700;">
            <span>🛡️ ${prod.organicCertification || 'Farmer Verified'}</span>
          </div>

          <div class="card-footer">
            <div class="card-price-wrap">
              <span class="card-price">₹${prod.price}</span>
              <span class="card-unit">per ${prod.unit} • Stock: ${prod.availableQuantity} ${prod.unit}</span>
            </div>
            <div style="display:flex; gap:0.4rem;">
              <button class="btn btn-secondary btn-sm" onclick="Marketplace.viewProductDetails('${prod.id}')" title="View Details">
                👁️ View
              </button>
              <button class="btn btn-primary btn-sm" onclick="Marketplace.quickAddToCart('${prod.id}')" ${prod.availableQuantity <= 0 ? 'disabled' : ''}>
                🛒 ${prod.availableQuantity > 0 ? 'Add' : 'Out of Stock'}
              </button>
            </div>
          </div>
        </div>
      </div>
    `).join('');
  },

  quickAddToCart(productId) {
    const product = State.products.find(p => p.id === productId);
    if (!product) return;

    if (!State.currentUser) {
      App.showAuthModal('login', 'Please log in as Customer to purchase farm produce.');
      return;
    }

    if (State.currentUser.role !== 'customer') {
      Toast.show('Only registered customers can add products to cart. Please log in with a customer account.', 'error');
      return;
    }

    State.addToCart(product, 1);
  },

  viewProductDetails(productId) {
    const product = State.products.find(p => p.id === productId);
    if (!product) return;

    const modalBody = document.getElementById('product-detail-modal-body');
    if (!modalBody) return;

    modalBody.innerHTML = `
      <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; align-items: start;">
        <div style="border-radius: var(--radius-lg); overflow:hidden; border:1px solid var(--slate-200);">
          <img src="${product.image || '/assets/products/ponni_rice.jpg'}" alt="${product.name}" style="width:100%; height:260px; object-fit:cover;">
          <div style="padding:0.75rem; background:var(--slate-50); font-size:0.8rem; color:var(--slate-600);">
            <strong>AWS S3 Object URI:</strong><br>
            <code style="color:var(--aws-orange); word-break:break-all;">s3://tn-farmer-produce/assets/${product.id}.jpg</code>
          </div>
        </div>
        <div>
          <span class="badge badge-confirmed" style="margin-bottom:0.5rem;">${product.category}</span>
          <h2 style="font-size:1.4rem; font-weight:800; color:var(--slate-900); margin-bottom:0.4rem;">${product.name}</h2>
          <p style="color:var(--slate-500); font-size:0.85rem; margin-bottom:1rem;">Cultivated by <strong>${product.farmerName}</strong> in <strong>${product.location}</strong></p>
          
          <div style="background:var(--primary-light); padding:0.75rem 1rem; border-radius:var(--radius-md); margin-bottom:1rem; border:1px solid var(--primary-border);">
            <div style="font-size:1.5rem; font-weight:800; color:var(--primary);">₹${product.price} <span style="font-size:0.85rem; font-weight:600; color:var(--slate-600);">/ ${product.unit}</span></div>
            <div style="font-size:0.8rem; color:var(--slate-600); margin-top:0.2rem;">Available Batch Stock: <strong>${product.availableQuantity} ${product.unit}</strong></div>
          </div>

          <div style="margin-bottom:1rem; font-size:0.88rem; color:var(--slate-700); line-height:1.5;">
            <strong>Produce Details:</strong><br>
            ${product.description}
          </div>

          <div style="display:flex; flex-direction:column; gap:0.4rem; font-size:0.8rem; color:var(--slate-600); margin-bottom:1.5rem;">
            <div>📅 <strong>Harvest Date:</strong> ${product.harvestDate || 'Fresh Weekly Harvest'}</div>
            <div>📜 <strong>Quality / Certification:</strong> ${product.organicCertification || 'TN Organic Farmers Council'}</div>
            <div>📍 <strong>Dispatch Logistics:</strong> Direct from ${product.district} Collection Hub</div>
          </div>

          <div style="display:flex; align-items:center; gap:0.75rem;">
            <div style="display:flex; align-items:center; border:1px solid var(--slate-300); border-radius:var(--radius-md); overflow:hidden;">
              <button style="padding:0.5rem 0.8rem; background:var(--slate-100);" onclick="Marketplace.adjustDetailQty(-1)">-</button>
              <input type="number" id="detail-qty" value="1" min="1" max="${product.availableQuantity}" style="width:50px; text-align:center; border:none; outline:none; font-weight:700;">
              <button style="padding:0.5rem 0.8rem; background:var(--slate-100);" onclick="Marketplace.adjustDetailQty(1)">+</button>
            </div>
            <button class="btn btn-primary" style="flex:1;" onclick="Marketplace.addFromDetail('${product.id}')">
              🛒 Add to Basket
            </button>
          </div>
        </div>
      </div>
    `;

    App.openModal('product-detail-modal');
  },

  adjustDetailQty(delta) {
    const input = document.getElementById('detail-qty');
    if (!input) return;
    let val = parseInt(input.value) + delta;
    if (val < 1) val = 1;
    input.value = val;
  },

  addFromDetail(productId) {
    const product = State.products.find(p => p.id === productId);
    const input = document.getElementById('detail-qty');
    const qty = input ? parseInt(input.value) || 1 : 1;

    if (!State.currentUser) {
      App.closeModal('product-detail-modal');
      App.showAuthModal('login', 'Please log in as Customer to add items.');
      return;
    }

    if (State.currentUser.role !== 'customer') {
      Toast.show('Only customer accounts can place orders.', 'error');
      return;
    }

    State.addToCart(product, qty);
    App.closeModal('product-detail-modal');
  },

  // Cart Modal & Checkout
  renderCart() {
    const itemsContainer = document.getElementById('cart-items-list');
    const totalsContainer = document.getElementById('cart-totals-summary');
    if (!itemsContainer || !totalsContainer) return;

    if (State.cart.length === 0) {
      itemsContainer.innerHTML = `
        <div style="text-align:center; padding:3rem 1rem;">
          <div style="font-size:3rem; margin-bottom:0.75rem;">🧺</div>
          <h4 style="font-weight:700; color:var(--slate-800);">Your produce basket is empty</h4>
          <p style="color:var(--slate-500); font-size:0.85rem; margin-top:0.3rem;">Explore fresh farm products listed directly by Tamil Nadu farmers!</p>
          <button class="btn btn-primary btn-sm" style="margin-top:1rem;" onclick="App.closeModal('cart-modal')">Browse Catalog</button>
        </div>
      `;
      totalsContainer.innerHTML = '';
      return;
    }

    itemsContainer.innerHTML = State.cart.map(item => `
      <div style="display:flex; align-items:center; justify-content:space-between; padding:0.85rem 0; border-bottom:1px solid var(--slate-100); gap:1rem;">
        <div style="display:flex; align-items:center; gap:0.75rem;">
          <img src="${item.image || '/assets/products/ponni_rice.jpg'}" alt="${item.name}" style="width:50px; height:50px; border-radius:var(--radius-md); object-fit:cover;">
          <div>
            <div style="font-weight:700; font-size:0.92rem; color:var(--slate-900);">${item.name}</div>
            <div style="font-size:0.78rem; color:var(--slate-500);">Farmer: ${item.farmerName} (${item.farmerDistrict})</div>
            <div style="font-weight:700; color:var(--primary); font-size:0.88rem; margin-top:0.2rem;">₹${item.price} / ${item.unit}</div>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:0.75rem;">
          <div style="display:flex; align-items:center; border:1px solid var(--slate-200); border-radius:var(--radius-sm); overflow:hidden;">
            <button style="padding:0.2rem 0.6rem; background:var(--slate-100);" onclick="Marketplace.updateItemQty('${item.productId}', ${item.quantity - 1})">-</button>
            <span style="padding:0.2rem 0.6rem; font-weight:700; font-size:0.85rem;">${item.quantity}</span>
            <button style="padding:0.2rem 0.6rem; background:var(--slate-100);" onclick="Marketplace.updateItemQty('${item.productId}', ${item.quantity + 1})">+</button>
          </div>
          <div style="font-weight:800; font-size:0.95rem; min-width:65px; text-align:right;">₹${item.price * item.quantity}</div>
          <button style="color:var(--danger); font-size:1.1rem; padding:0.2rem;" onclick="Marketplace.removeItem('${item.productId}')" title="Remove">✕</button>
        </div>
      </div>
    `).join('');

    const { subtotal, deliveryFee, total } = State.getCartTotal();

    totalsContainer.innerHTML = `
      <div style="background:var(--slate-50); padding:1rem; border-radius:var(--radius-md); border:1px solid var(--slate-200); margin-top:1rem;">
        <div style="display:flex; justify-content:space-between; font-size:0.88rem; margin-bottom:0.4rem; color:var(--slate-600);">
          <span>Farm Produce Subtotal</span>
          <span>₹${subtotal}</span>
        </div>
        <div style="display:flex; justify-content:space-between; font-size:0.88rem; margin-bottom:0.4rem; color:var(--slate-600);">
          <span>Multi-Stage Logistics Fee (TN Cold Chain)</span>
          <span>${deliveryFee === 0 ? '<strong style="color:var(--primary);">FREE (Orders > ₹500)</strong>' : `₹${deliveryFee}`}</span>
        </div>
        <div style="display:flex; justify-content:space-between; font-size:1.15rem; font-weight:800; color:var(--slate-900); border-top:1px dashed var(--slate-300); padding-top:0.6rem; margin-top:0.6rem;">
          <span>Grand Total Payable</span>
          <span style="color:var(--primary);">₹${total}</span>
        </div>
      </div>
    `;
  },

  updateItemQty(productId, qty) {
    State.updateCartQuantity(productId, qty);
    this.renderCart();
  },

  removeItem(productId) {
    State.removeFromCart(productId);
    this.renderCart();
  },

  openCheckout() {
    if (State.cart.length === 0) {
      Toast.show('Your cart is empty!', 'error');
      return;
    }

    if (!State.currentUser) {
      App.closeModal('cart-modal');
      App.showAuthModal('login', 'Please log in as a customer to checkout.');
      return;
    }

    if (State.currentUser.role !== 'customer') {
      Toast.show('Only customers can checkout.', 'error');
      return;
    }

    App.closeModal('cart-modal');

    // Pre-fill user details into checkout form
    const user = State.currentUser;
    const nameInput = document.getElementById('checkout-name');
    const phoneInput = document.getElementById('checkout-phone');
    const streetInput = document.getElementById('checkout-street');
    const districtInput = document.getElementById('checkout-district');
    const pincodeInput = document.getElementById('checkout-pincode');

    if (nameInput) nameInput.value = user.name || '';
    if (phoneInput) phoneInput.value = user.phone || '';
    if (streetInput) streetInput.value = user.address || '';
    if (districtInput) districtInput.value = user.district || 'Chennai';
    if (pincodeInput) pincodeInput.value = user.pincode || '';

    const { subtotal, deliveryFee, total } = State.getCartTotal();
    const summaryEl = document.getElementById('checkout-total-summary');
    if (summaryEl) {
      summaryEl.innerHTML = `Grand Total: <strong style="color:var(--primary); font-size:1.25rem;">₹${total}</strong> (${State.cart.length} items)`;
    }

    App.openModal('checkout-modal');
  },

  selectPaymentMethod(method) {
    document.querySelectorAll('.payment-tab-btn').forEach(btn => btn.classList.remove('active'));
    const targetBtn = document.getElementById(`pay-tab-${method.toLowerCase()}`);
    if (targetBtn) targetBtn.classList.add('active');

    document.querySelectorAll('.payment-panel').forEach(p => p.style.display = 'none');
    const panel = document.getElementById(`pay-panel-${method.toLowerCase()}`);
    if (panel) panel.style.display = 'block';
  },

  async submitOrder(e) {
    e.preventDefault();

    const name = document.getElementById('checkout-name').value.trim();
    const phone = document.getElementById('checkout-phone').value.trim();
    const street = document.getElementById('checkout-street').value.trim();
    const district = document.getElementById('checkout-district').value;
    const pincode = document.getElementById('checkout-pincode').value.trim();

    if (!name || !phone || !street || !pincode) {
      Toast.show('Please fill in all address fields.', 'error');
      return;
    }

    // Determine selected payment method
    let paymentMethod = 'UPI';
    const activePayBtn = document.querySelector('.payment-tab-btn.active');
    if (activePayBtn) {
      paymentMethod = activePayBtn.dataset.method;
    }

    const submitBtn = document.getElementById('btn-place-order');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '⚡ Processing via AWS Lambda & SQS...';
    }

    try {
      const orderPayload = {
        items: State.cart,
        deliveryAddress: {
          name,
          phone,
          street,
          district,
          state: 'Tamil Nadu',
          pincode
        },
        paymentMethod,
        paymentDetails: {
          upiId: `${name.toLowerCase().replace(/\s+/g, '')}@okaxis`,
          cardNumber: '4111222233334444'
        }
      };

      const res = await API.createOrder(orderPayload);

      State.clearCart();
      App.closeModal('checkout-modal');

      Toast.show(`🎉 Order #${res.order.id} placed successfully! Notification sent via AWS SNS.`, 'success', 5000);

      // Open the Tracking Modal immediately
      App.showOrderTracking(res.order.id);

    } catch (err) {
      Toast.show(err.message || 'Order failed. Please try again.', 'error');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '✅ Confirm & Place Order (Simulated Payment)';
      }
    }
  }
};
