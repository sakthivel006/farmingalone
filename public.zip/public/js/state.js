// Farmer Produce Marketing - Application State Management
const State = {
  currentUser: null,
  cart: [],
  products: [],
  orders: [],
  filters: {
    category: 'All',
    district: 'All',
    search: '',
    sort: 'newest'
  },
  activeTab: 'marketplace',

  init() {
    this.currentUser = API.getCurrentUser();
    this.loadCart();
  },

  // Cart Management
  loadCart() {
    try {
      const saved = localStorage.getItem('agri_cart');
      this.cart = saved ? JSON.parse(saved) : [];
    } catch (e) {
      this.cart = [];
    }
    this.updateCartBadge();
  },

  saveCart() {
    localStorage.setItem('agri_cart', JSON.stringify(this.cart));
    this.updateCartBadge();
  },

  addToCart(product, quantity = 1) {
    const qty = parseFloat(quantity);
    const existing = this.cart.find(item => item.productId === product.id);

    if (existing) {
      existing.quantity += qty;
    } else {
      this.cart.push({
        productId: product.id,
        name: product.name,
        price: product.price,
        unit: product.unit,
        image: product.image,
        farmerId: product.farmerId,
        farmerName: product.farmerName,
        farmerDistrict: product.district,
        quantity: qty
      });
    }

    this.saveCart();
    Toast.show(`Added ${qty} ${product.unit} of ${product.name} to cart`, 'success');
  },

  updateCartQuantity(productId, quantity) {
    const qty = parseFloat(quantity);
    if (qty <= 0) {
      this.removeFromCart(productId);
      return;
    }

    const item = this.cart.find(i => i.productId === productId);
    if (item) {
      item.quantity = qty;
      this.saveCart();
    }
  },

  removeFromCart(productId) {
    this.cart = this.cart.filter(item => item.productId !== productId);
    this.saveCart();
  },

  clearCart() {
    this.cart = [];
    this.saveCart();
  },

  getCartTotal() {
    const subtotal = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryFee = subtotal === 0 ? 0 : (subtotal >= 500 ? 0 : 40);
    return {
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee
    };
  },

  updateCartBadge() {
    const countEl = document.getElementById('cart-badge-count');
    if (countEl) {
      const totalCount = this.cart.reduce((sum, item) => sum + item.quantity, 0);
      countEl.textContent = totalCount;
      countEl.style.display = totalCount > 0 ? 'flex' : 'none';
    }
  }
};

// Toast Notifications System
const Toast = {
  container: null,

  ensureContainer() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  },

  show(message, type = 'info', duration = 3800) {
    this.ensureContainer();

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = '🌾';
    if (type === 'error') icon = '⚠️';
    if (type === 'aws') icon = '☁️';
    if (type === 'success') icon = '✅';

    toast.innerHTML = `
      <div style="display:flex; align-items:center; gap:0.6rem;">
        <span style="font-size:1.15rem;">${icon}</span>
        <span style="font-size:0.9rem; font-weight:600; color:var(--slate-800);">${message}</span>
      </div>
      <button style="color:var(--slate-400); font-size:1.2rem; line-height:1;" onclick="this.parentElement.remove()">×</button>
    `;

    this.container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.remove();
      }
    }, duration);
  }
};
