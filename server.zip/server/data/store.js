const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_FILE = path.join(__dirname, 'db.json');

// Helper to safely read database
function readDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      initSeedData();
    }
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading DB, re-initializing...', err);
    return initSeedData();
  }
}

// Helper to safely write database
function writeDb(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing DB:', err);
    return false;
  }
}

// Seed initial data
function initSeedData() {
  const salt = bcrypt.genSaltSync(10);

  // Pre-hashed passwords:
  // Admin@123, Farmer@123, Customer@123
  const adminPass = bcrypt.hashSync('Admin@123', salt);
  const farmerPass = bcrypt.hashSync('Farmer@123', salt);
  const customerPass = bcrypt.hashSync('Customer@123', salt);

  const initialData = {
    users: [
      {
        id: 'usr-admin-01',
        name: 'Agricultural Directorate Admin',
        email: 'admin@agri.gov.in',
        phone: '9444012345',
        password: adminPass,
        role: 'admin',
        address: 'Ezhilagam, Kamarajar Salai, Chepauk',
        district: 'Chennai',
        state: 'Tamil Nadu',
        pincode: '600005',
        createdAt: '2026-09-01T08:00:00.000Z'
      },
      {
        id: 'usr-farmer-01',
        name: 'Selvam Murugan',
        email: 'selvam@farmer.tn.in',
        phone: '9842109876',
        password: farmerPass,
        role: 'farmer',
        address: '14 Meenakshi Amman Kovil Street, Sholavandan',
        district: 'Madurai',
        state: 'Tamil Nadu',
        pincode: '625214',
        farmName: 'Sholavandan Green Organic Paddy Farms',
        createdAt: '2026-09-02T09:30:00.000Z'
      },
      {
        id: 'usr-farmer-02',
        name: 'Velusamy Kandasamy',
        email: 'velu@farmer.tn.in',
        phone: '9786112233',
        password: farmerPass,
        role: 'farmer',
        address: '7 Kaveri River Road, Mettur',
        district: 'Salem',
        state: 'Tamil Nadu',
        pincode: '636401',
        farmName: 'Salem Royal Mango & Coconut Orchards',
        createdAt: '2026-09-05T10:15:00.000Z'
      },
      {
        id: 'usr-farmer-03',
        name: 'Kavitha Rajan',
        email: 'kavitha@farmer.tn.in',
        phone: '9443217890',
        password: farmerPass,
        role: 'farmer',
        address: '22 Tea Valley Terrace, Kotagiri',
        district: 'Nilgiris',
        state: 'Tamil Nadu',
        pincode: '643217',
        farmName: 'Nilgiris High Altitude Vegetable Farm',
        createdAt: '2026-09-10T11:00:00.000Z'
      },
      {
        id: 'usr-cust-01',
        name: 'Anand Sundaram',
        email: 'anand@customer.tn.in',
        phone: '9884012345',
        password: customerPass,
        role: 'customer',
        address: 'Flat 4B, Green Meadows Apt, 2nd Avenue, Anna Nagar',
        district: 'Chennai',
        state: 'Tamil Nadu',
        pincode: '600040',
        createdAt: '2026-09-15T14:20:00.000Z'
      },
      {
        id: 'usr-cust-02',
        name: 'Priya Ramanathan',
        email: 'priya@customer.tn.in',
        phone: '9944123456',
        password: customerPass,
        role: 'customer',
        address: '15 Race Course Road, Near Thomas Park',
        district: 'Coimbatore',
        state: 'Tamil Nadu',
        pincode: '641018',
        createdAt: '2026-09-18T16:45:00.000Z'
      }
    ],

    collectionCentres: [
      { id: 'VCC-MDU-01', name: 'Madurai Agri Collection Center (Sholavandan)', district: 'Madurai', incharge: 'K. Senthil Nathan', contact: '+91 9442111001' },
      { id: 'VCC-SLM-02', name: 'Salem Farm Collection Depot (Mettur)', district: 'Salem', incharge: 'M. Palaniswamy', contact: '+91 9442111002' },
      { id: 'VCC-NLG-03', name: 'Nilgiris Hill Produce Station (Kotagiri)', district: 'Nilgiris', incharge: 'J. Ronald Fernandez', contact: '+91 9442111003' },
      { id: 'VCC-ERD-04', name: 'Erode Organic Assembly Center (Perundurai)', district: 'Erode', incharge: 'P. Subramanian', contact: '+91 9442111004' },
      { id: 'VCC-TNJ-05', name: 'Thanjavur Delta Rice Collection Point (Kumbakonam)', district: 'Thanjavur', incharge: 'R. Anbarasan', contact: '+91 9442111005' },
      { id: 'VCC-CBE-06', name: 'Pollachi Coconut & Fruit Assembly (Pollachi)', district: 'Coimbatore', incharge: 'A. Marimuthu', contact: '+91 9442111006' }
    ],

    districtHubs: [
      { id: 'HUB-CHN-01', name: 'Chennai Central Agro Logistics Hub (Koyambedu)', district: 'Chennai', capacityTons: 50, manager: 'S. Rajendran' },
      { id: 'HUB-CBE-02', name: 'Coimbatore Western Regional Hub (Singanallur)', district: 'Coimbatore', capacityTons: 35, manager: 'T. Karthikeyan' },
      { id: 'HUB-TRZ-03', name: 'Tiruchirappalli Central Junction Hub (Thuvakudi)', district: 'Tiruchirappalli', capacityTons: 40, manager: 'N. Muthuraman' },
      { id: 'HUB-MDU-04', name: 'Madurai Southern Gateway Hub (Koodal Nagar)', district: 'Madurai', capacityTons: 30, manager: 'V. Alagarsamy' },
      { id: 'HUB-SLM-05', name: 'Salem Steel City Agro Logistics Hub (Suramangalam)', district: 'Salem', capacityTons: 25, manager: 'G. Vijayakumar' }
    ],

    deliveryPartners: [
      { id: 'DP-01', name: 'Ravi Kumar', agency: 'SpeedAgri Logistics', phone: '+91 9876543210', district: 'Chennai', vehicle: 'Tata Ace (TN 02 BX 4412)' },
      { id: 'DP-02', name: 'Suresh Mani', agency: 'Western Agro Courier', phone: '+91 9876543211', district: 'Coimbatore', vehicle: 'Mahindra Bolero Maxi (TN 37 CY 8820)' },
      { id: 'DP-03', name: 'Dinesh Babu', agency: 'Kaveri Fast Transit', phone: '+91 9876543212', district: 'Tiruchirappalli', vehicle: 'Piaggio Ape Cargo (TN 45 DZ 1923)' },
      { id: 'DP-04', name: 'Murugan Thangaraj', agency: 'Pandiyan Express', phone: '+91 9876543213', district: 'Madurai', vehicle: 'Maruti Super Carry (TN 58 AB 5501)' }
    ],

    products: [
      {
        id: 'prod-001',
        farmerId: 'usr-farmer-01',
        farmerName: 'Selvam Murugan',
        name: 'Thanjavur Traditional Organic Ponni Boiled Rice',
        category: 'Grains & Cereals',
        price: 65,
        unit: 'kg',
        availableQuantity: 450,
        district: 'Madurai',
        location: 'Sholavandan, Madurai',
        description: 'Single-origin traditional Ponni boiled rice cultivated with vermicompost and canal irrigation. Naturally aged for 12 months for fluffy non-sticky grains.',
        image: '/assets/products/ponni_rice.jpg',
        organicCertification: 'TNOCD/ORG/2026/089',
        harvestDate: '2026-08-20',
        createdAt: '2026-09-02T10:00:00.000Z'
      },
      {
        id: 'prod-002',
        farmerId: 'usr-farmer-02',
        farmerName: 'Velusamy Kandasamy',
        name: 'Salem Sweet Malgova Mangoes (Natural Tree-Ripened)',
        category: 'Fruits',
        price: 140,
        unit: 'kg',
        availableQuantity: 120,
        district: 'Salem',
        location: 'Mettur, Salem',
        description: 'Authentic Salem Malgova mangoes grown naturally without calcium carbide or synthetic chemicals. Incredibly sweet aroma and tender pulpy texture.',
        image: '/assets/products/salem_mangoes.jpg',
        organicCertification: 'TNOCD/ORG/2026/142',
        harvestDate: '2026-09-12',
        createdAt: '2026-09-05T11:00:00.000Z'
      },
      {
        id: 'prod-003',
        farmerId: 'usr-farmer-03',
        farmerName: 'Kavitha Rajan',
        name: 'Ooty Hill Crisp Vegetables Assortment Crate',
        category: 'Vegetables',
        price: 85,
        unit: 'kg',
        availableQuantity: 280,
        district: 'Nilgiris',
        location: 'Kotagiri, Nilgiris',
        description: 'Crisp organic mountain carrots, tender French beans, and vine-ripened tomatoes harvested fresh every morning from terraced Nilgiris hill slopes.',
        image: '/assets/products/ooty_vegetables.jpg',
        organicCertification: 'NILGIRIS-ECO-GREEN-33',
        harvestDate: '2026-09-28',
        createdAt: '2026-09-10T12:00:00.000Z'
      },
      {
        id: 'prod-004',
        farmerId: 'usr-farmer-01',
        farmerName: 'Selvam Murugan',
        name: 'Pure Erode Golden Sun-Dried Turmeric Powder',
        category: 'Spices & Herbs',
        price: 210,
        unit: 'kg',
        availableQuantity: 160,
        district: 'Madurai',
        location: 'Perundurai Agro Belt',
        description: 'High-curcumin (5.2%) GI-tagged Erode turmeric roots, stone-ground at low temperatures to retain therapeutic essential oils and golden hue.',
        image: '/assets/products/erode_turmeric.jpg',
        organicCertification: 'INDIA-ORGANIC-TC-98',
        harvestDate: '2026-07-15',
        createdAt: '2026-09-12T14:30:00.000Z'
      },
      {
        id: 'prod-005',
        farmerId: 'usr-farmer-02',
        farmerName: 'Velusamy Kandasamy',
        name: 'Pollachi Sweet Tender Coconuts (Pack of 4)',
        category: 'Fruits',
        price: 180,
        unit: 'pack',
        availableQuantity: 90,
        district: 'Salem',
        location: 'Pollachi Valley',
        description: 'Farm-picked jumbo tender coconuts filled with sweet mineral-rich electrolyte water and delicate malai, packed fresh in eco-friendly protective netting.',
        image: '/assets/hero_agri_banner.jpg',
        organicCertification: 'TNOCD/ORG/2026/054',
        harvestDate: '2026-09-27',
        createdAt: '2026-09-14T09:00:00.000Z'
      }
    ],

    orders: [
      {
        id: 'ORD-TN-8901',
        customerId: 'usr-cust-01',
        customerName: 'Anand Sundaram',
        customerEmail: 'anand@customer.tn.in',
        customerPhone: '9884012345',
        deliveryAddress: {
          name: 'Anand Sundaram',
          street: 'Flat 4B, Green Meadows Apt, 2nd Avenue, Anna Nagar',
          district: 'Chennai',
          state: 'Tamil Nadu',
          pincode: '600040'
        },
        items: [
          {
            productId: 'prod-001',
            name: 'Thanjavur Traditional Organic Ponni Boiled Rice',
            price: 65,
            quantity: 10,
            unit: 'kg',
            farmerId: 'usr-farmer-01',
            farmerName: 'Selvam Murugan',
            farmerDistrict: 'Madurai',
            image: '/assets/products/ponni_rice.jpg'
          },
          {
            productId: 'prod-002',
            name: 'Salem Sweet Malgova Mangoes (Natural Tree-Ripened)',
            price: 140,
            quantity: 3,
            unit: 'kg',
            farmerId: 'usr-farmer-02',
            farmerName: 'Velusamy Kandasamy',
            farmerDistrict: 'Salem',
            image: '/assets/products/salem_mangoes.jpg'
          }
        ],
        subtotal: 1070,
        deliveryFee: 0,
        total: 1070,
        payment: {
          method: 'UPI',
          upiId: 'anand.sundaram@okhdfcbank',
          transactionId: 'TXN-AWS-PAY-9812491',
          status: 'PAID',
          paidAt: '2026-09-28T10:15:00.000Z'
        },
        orderStatus: 'IN_TRANSIT_TO_DISTRICT_HUB',
        logistics: {
          collectionCentre: 'Madurai Agri Collection Center (Sholavandan)',
          districtHub: 'Chennai Central Agro Logistics Hub (Koyambedu)',
          deliveryPerson: 'Ravi Kumar (SpeedAgri Logistics - +91 9876543210)',
          timeline: [
            {
              status: 'PLACED',
              title: 'Order Placed & Payment Verified',
              location: 'Customer App - Anna Nagar, Chennai',
              timestamp: '2026-09-28T10:15:00.000Z',
              note: 'Payment of ₹1070 received via AWS Payment Gateway Lambda'
            },
            {
              status: 'FARMER_CONFIRMED',
              title: 'Farmers Accepted & Packaged',
              location: 'Sholavandan & Mettur Farm Orchards',
              timestamp: '2026-09-28T11:45:00.000Z',
              note: 'Farmers inspected produce quality and tagged with QR barcode'
            },
            {
              status: 'RECEIVED_AT_COLLECTION_CENTRE',
              title: 'Received at Village Collection Centre',
              location: 'Madurai Agri Collection Center (Sholavandan)',
              timestamp: '2026-09-28T15:30:00.000Z',
              note: 'Consolidated into temperature-controlled regional dispatch crate'
            },
            {
              status: 'IN_TRANSIT_TO_DISTRICT_HUB',
              title: 'In Transit via State Agro Expressway',
              location: 'NH45 Transit Corridor towards Chennai',
              timestamp: '2026-09-29T06:00:00.000Z',
              note: 'Scheduled arrival at Chennai Koyambedu Hub by 14:00'
            }
          ]
        },
        createdAt: '2026-09-28T10:15:00.000Z',
        updatedAt: '2026-09-29T06:00:00.000Z'
      }
    ],

    awsSimulation: {
      region: 'ap-south-1 (Asia Pacific - Mumbai)',
      az: 'ap-south-1a (Subnet: subnet-0f72a819b)',
      ec2: {
        instanceId: 'i-0a89d71c42b109e',
        instanceType: 't3.medium (2 vCPU, 4 GiB RAM)',
        status: 'RUNNING',
        uptimeHours: 342,
        cpuUtilizationPercent: 18.4,
        memoryUsagePercent: 42.1,
        totalRequestsHandled: 12480
      },
      s3: {
        bucketName: 's3://tn-farmer-produce-marketing-media-prod',
        totalObjects: 48,
        storageClass: 'STANDARD',
        storageSizeBytes: 24890120,
        encryption: 'AWS-KMS (aws/s3)',
        presignedUrlsGenerated: 612
      },
      dynamoDb: {
        tables: [
          { name: 'TN_Farmer_Users', itemCount: 6, readCapacityUnits: 5, writeCapacityUnits: 5, status: 'ACTIVE' },
          { name: 'TN_Farmer_Products', itemCount: 5, readCapacityUnits: 10, writeCapacityUnits: 5, status: 'ACTIVE' },
          { name: 'TN_Farmer_Orders', itemCount: 1, readCapacityUnits: 10, writeCapacityUnits: 10, status: 'ACTIVE' },
          { name: 'TN_Farmer_Logistics_Tracking', itemCount: 4, readCapacityUnits: 5, writeCapacityUnits: 5, status: 'ACTIVE' }
        ]
      },
      sns: {
        topicArn: 'arn:aws:sns:ap-south-1:892019482012:TN_FarmerProduceAlerts',
        totalNotificationsSent: 38,
        recentDispatches: [
          {
            id: 'sns-msg-901',
            type: 'SMS',
            recipient: '+91 9884012345 (Customer: Anand)',
            message: 'Your Farmer Produce Order #ORD-TN-8901 is now IN TRANSIT to Chennai Central Hub.',
            timestamp: '2026-09-29T06:00:00.000Z',
            status: 'DELIVERED'
          },
          {
            id: 'sns-msg-902',
            type: 'EMAIL',
            recipient: 'selvam@farmer.tn.in (Farmer: Selvam)',
            message: 'Order #ORD-TN-8901 items dispatched from Sholavandan Collection Centre.',
            timestamp: '2026-09-28T15:30:00.000Z',
            status: 'DELIVERED'
          }
        ]
      },
      cloudWatch: {
        alarmStatus: 'OK',
        p95LatencyMs: 42,
        errorRatePercent: 0.02,
        recentLogs: [
          { timestamp: '2026-09-29T16:50:12.000Z', level: 'INFO', service: 'AWS-AppRunner', message: 'HTTP 200 GET /api/products - duration: 24ms' },
          { timestamp: '2026-09-29T16:52:04.000Z', level: 'INFO', service: 'Amazon-DynamoDB', message: 'BatchGetItem TN_Farmer_Products - consumed 1.5 RCU' },
          { timestamp: '2026-09-29T17:05:44.000Z', level: 'INFO', service: 'Amazon-SNS', message: 'Published message ID sns-msg-901 to topic TN_FarmerProduceAlerts' }
        ]
      }
    }
  };

  fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf8');
  return initialData;
}

module.exports = {
  readDb,
  writeDb,
  initSeedData
};
