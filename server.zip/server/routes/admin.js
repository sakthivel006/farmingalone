const express = require('express');
const router = express.Router();
const { readDb, writeDb } = require('../data/store');
const { authenticateToken } = require('./auth');

// Middleware to enforce Admin role
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Access forbidden. Administrator role required.' });
  }
  next();
}

// GET /api/admin/dashboard - High-level KPIs and summaries
router.get('/dashboard', authenticateToken, requireAdmin, (req, res) => {
  try {
    const db = readDb();
    const farmers = db.users.filter(u => u.role === 'farmer');
    const customers = db.users.filter(u => u.role === 'customer');
    const products = db.products || [];
    const orders = db.orders || [];

    const totalSales = orders
      .filter(o => o.orderStatus !== 'CANCELLED' && o.payment?.status === 'PAID')
      .reduce((sum, o) => sum + (o.total || 0), 0);

    const pendingOrdersCount = orders.filter(o => o.orderStatus !== 'DELIVERED' && o.orderStatus !== 'CANCELLED').length;
    const completedOrdersCount = orders.filter(o => o.orderStatus === 'DELIVERED').length;

    // Sales by District
    const salesByDistrict = {};
    orders.forEach(o => {
      const dist = o.deliveryAddress?.district || 'Other';
      salesByDistrict[dist] = (salesByDistrict[dist] || 0) + (o.total || 0);
    });

    // Top Selling Products
    const productSalesMap = {};
    orders.forEach(o => {
      (o.items || []).forEach(item => {
        if (!productSalesMap[item.name]) {
          productSalesMap[item.name] = { name: item.name, quantity: 0, revenue: 0, district: item.farmerDistrict };
        }
        productSalesMap[item.name].quantity += item.quantity;
        productSalesMap[item.name].revenue += item.price * item.quantity;
      });
    });

    const topProducts = Object.values(productSalesMap).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

    return res.json({
      success: true,
      stats: {
        totalFarmers: farmers.length,
        totalCustomers: customers.length,
        totalProducts: products.length,
        totalOrders: orders.length,
        totalSales,
        pendingOrders: pendingOrdersCount,
        completedOrders: completedOrdersCount,
        collectionCentresCount: db.collectionCentres?.length || 0,
        districtHubsCount: db.districtHubs?.length || 0,
        deliveryPartnersCount: db.deliveryPartners?.length || 0
      },
      salesByDistrict,
      topProducts,
      recentOrders: orders.slice(0, 5)
    });
  } catch (err) {
    console.error('Admin dashboard error:', err);
    return res.status(500).json({ success: false, message: 'Could not fetch admin statistics.' });
  }
});

// GET /api/admin/users - Manage farmers and customers
router.get('/users', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { role } = req.query;
    const db = readDb();
    let users = db.users.map(({ password, ...u }) => u);

    if (role) {
      users = users.filter(u => u.role === role);
    }

    return res.json({ success: true, count: users.length, users });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Error fetching users.' });
  }
});

// DELETE /api/admin/users/:id - Delete a user
router.delete('/users/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const db = readDb();
    const idx = db.users.findIndex(u => u.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }
    if (db.users[idx].role === 'admin') {
      return res.status(400).json({ success: false, message: 'Cannot delete primary administrator.' });
    }
    const deleted = db.users.splice(idx, 1)[0];
    writeDb(db);
    return res.json({ success: true, message: `User ${deleted.name} removed successfully.` });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to delete user.' });
  }
});

// GET /api/admin/logistics-options - Fetch centres, hubs, partners
router.get('/logistics-options', authenticateToken, requireAdmin, (req, res) => {
  try {
    const db = readDb();
    return res.json({
      success: true,
      collectionCentres: db.collectionCentres || [],
      districtHubs: db.districtHubs || [],
      deliveryPartners: db.deliveryPartners || []
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Could not load logistics config.' });
  }
});

// PUT /api/admin/orders/:id/logistics - Assign Collection Centre, District Hub, Delivery Partner
router.put('/orders/:id/logistics', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { collectionCentre, districtHub, deliveryPerson } = req.body;
    const db = readDb();
    const order = db.orders.find(o => o.id === req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    if (!order.logistics) order.logistics = {};
    if (collectionCentre) order.logistics.collectionCentre = collectionCentre;
    if (districtHub) order.logistics.districtHub = districtHub;
    if (deliveryPerson) order.logistics.deliveryPerson = deliveryPerson;

    order.updatedAt = new Date().toISOString();

    writeDb(db);

    return res.json({ success: true, message: 'Logistics routes and delivery partner assigned.', order });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to assign logistics.' });
  }
});

// PUT /api/admin/orders/:id/status - Update delivery status across Tamil Nadu pipeline
router.put('/orders/:id/status', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { status, note, location } = req.body;
    const validStatuses = [
      'PLACED',
      'FARMER_CONFIRMED',
      'DISPATCHED_TO_COLLECTION_CENTRE',
      'RECEIVED_AT_COLLECTION_CENTRE',
      'IN_TRANSIT_TO_DISTRICT_HUB',
      'RECEIVED_AT_DISTRICT_HUB',
      'OUT_FOR_DELIVERY',
      'DELIVERED',
      'CANCELLED'
    ];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid delivery status provided.' });
    }

    const db = readDb();
    const order = db.orders.find(o => o.id === req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    order.orderStatus = status;
    const now = new Date().toISOString();
    order.updatedAt = now;

    // Build friendly title
    const titles = {
      PLACED: 'Order Placed & Queued',
      FARMER_CONFIRMED: 'Farmer Confirmed Order',
      DISPATCHED_TO_COLLECTION_CENTRE: 'Dispatched to Village Collection Centre',
      RECEIVED_AT_COLLECTION_CENTRE: 'Received at Village Collection Centre',
      IN_TRANSIT_TO_DISTRICT_HUB: 'In Transit via State Agro Expressway',
      RECEIVED_AT_DISTRICT_HUB: 'Received at District Logistics Hub',
      OUT_FOR_DELIVERY: 'Out for Local Delivery to Customer Doorstep',
      DELIVERED: 'Successfully Delivered to Customer',
      CANCELLED: 'Order Cancelled'
    };

    if (!order.logistics) order.logistics = { timeline: [] };
    if (!order.logistics.timeline) order.logistics.timeline = [];

    order.logistics.timeline.push({
      status,
      title: titles[status] || status,
      location: location || (status.includes('COLLECTION') ? order.logistics.collectionCentre : (status.includes('HUB') ? order.logistics.districtHub : order.deliveryAddress.district)),
      timestamp: now,
      note: note || `Admin updated status to ${titles[status] || status}`
    });

    // CloudWatch & SNS Dispatches
    if (db.awsSimulation?.sns) {
      db.awsSimulation.sns.totalNotificationsSent += 1;
      db.awsSimulation.sns.recentDispatches.unshift({
        id: `sns-msg-${Date.now()}`,
        type: 'SMS',
        recipient: `${order.customerPhone} (${order.customerName})`,
        message: `Agri Order Update: Order #${order.id} is now ${titles[status]}. Track real-time on portal.`,
        timestamp: now,
        status: 'DELIVERED'
      });
    }

    if (db.awsSimulation?.cloudWatch?.recentLogs) {
      db.awsSimulation.cloudWatch.recentLogs.unshift({
        timestamp: now,
        level: 'INFO',
        service: 'AWS-StepFunctions/EventBridge',
        message: `Order ${order.id} transitioned to stage: ${status} -> ${order.customerName}`
      });
    }

    writeDb(db);

    return res.json({ success: true, message: `Delivery status updated to ${status}`, order });
  } catch (err) {
    console.error('Update status error:', err);
    return res.status(500).json({ success: false, message: 'Failed to update delivery status.' });
  }
});

// GET /api/admin/reports - Detailed reports for academic presentation
router.get('/reports', authenticateToken, requireAdmin, (req, res) => {
  try {
    const db = readDb();
    const orders = db.orders || [];
    const products = db.products || [];

    // Category breakdown
    const categoryBreakdown = {};
    products.forEach(p => {
      categoryBreakdown[p.category] = (categoryBreakdown[p.category] || 0) + 1;
    });

    // District breakdown
    const districtCoverage = {};
    db.users.forEach(u => {
      if (u.district) {
        districtCoverage[u.district] = districtCoverage[u.district] || { farmers: 0, customers: 0 };
        if (u.role === 'farmer') districtCoverage[u.district].farmers += 1;
        if (u.role === 'customer') districtCoverage[u.district].customers += 1;
      }
    });

    return res.json({
      success: true,
      reportGeneratedAt: new Date().toISOString(),
      categoryBreakdown,
      districtCoverage,
      ordersTotal: orders.length,
      revenueTotal: orders.reduce((sum, o) => sum + (o.total || 0), 0)
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Could not generate report.' });
  }
});

module.exports = router;
