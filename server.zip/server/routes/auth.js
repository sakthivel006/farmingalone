const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { readDb, writeDb } = require('../data/store');

const JWT_SECRET = process.env.JWT_SECRET || 'aws-farmer-cloud-secret-key-tamil-nadu-2026';

// Middleware to verify JWT token
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token.' });
  }
}

// POST /api/auth/register (Farmer or Customer only)
router.post('/register', (req, res) => {
  try {
    const { name, email, phone, password, confirmPassword, address, district, state, pincode, role, farmName } = req.body;

    if (!name || !email || !phone || !password || !address || !district || !pincode) {
      return res.status(400).json({ success: false, message: 'All required fields must be filled.' });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ success: false, message: 'Passwords do not match.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
    }

    const assignedRole = role === 'farmer' ? 'farmer' : 'customer';
    if (role === 'admin') {
      return res.status(403).json({ success: false, message: 'Security Policy: Admin registration is not open to public.' });
    }

    const db = readDb();
    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return res.status(409).json({ success: false, message: 'An account with this email address already exists.' });
    }

    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(password, salt);

    const newUser = {
      id: `usr-${assignedRole}-${Date.now()}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      password: hashedPassword,
      role: assignedRole,
      address: address.trim(),
      district: district.trim(),
      state: state || 'Tamil Nadu',
      pincode: pincode.trim(),
      farmName: assignedRole === 'farmer' ? (farmName || `${name.trim()}'s Agro Farm`) : undefined,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);

    // Update DynamoDB simulation stats
    const usersTable = db.awsSimulation?.dynamoDb?.tables.find(t => t.name === 'TN_Farmer_Users');
    if (usersTable) usersTable.itemCount += 1;

    // Log CloudWatch event
    if (db.awsSimulation?.cloudWatch?.recentLogs) {
      db.awsSimulation.cloudWatch.recentLogs.unshift({
        timestamp: new Date().toISOString(),
        level: 'INFO',
        service: 'Amazon-Cognito/DynamoDB',
        message: `Registered new ${assignedRole}: ${newUser.email} [${newUser.district}]`
      });
      if (db.awsSimulation.cloudWatch.recentLogs.length > 20) {
        db.awsSimulation.cloudWatch.recentLogs.pop();
      }
    }

    writeDb(db);

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name, district: newUser.district },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password: _, ...userWithoutPassword } = newUser;

    return res.status(201).json({
      success: true,
      message: `${assignedRole === 'farmer' ? 'Farmer' : 'Customer'} registered successfully!`,
      token,
      user: userWithoutPassword
    });
  } catch (err) {
    console.error('Registration error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error during registration.' });
  }
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide both email and password.' });
    }

    const db = readDb();
    const user = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials. User not found.' });
    }

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name, district: user.district },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // CloudWatch Log
    if (db.awsSimulation?.cloudWatch?.recentLogs) {
      db.awsSimulation.cloudWatch.recentLogs.unshift({
        timestamp: new Date().toISOString(),
        level: 'INFO',
        service: 'AWS-Cognito',
        message: `Auth token generated for ${user.role}: ${user.email}`
      });
      if (db.awsSimulation.cloudWatch.recentLogs.length > 20) {
        db.awsSimulation.cloudWatch.recentLogs.pop();
      }
      writeDb(db);
    }

    const { password: _, ...userWithoutPassword } = user;

    return res.json({
      success: true,
      message: 'Login successful!',
      token,
      user: userWithoutPassword
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'Internal server error during login.' });
  }
});

// GET /api/auth/me
router.get('/me', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }
    const { password: _, ...userWithoutPassword } = user;
    return res.json({ success: true, user: userWithoutPassword });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to fetch user data.' });
  }
});

// PUT /api/auth/profile
router.put('/profile', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    const userIndex = db.users.findIndex(u => u.id === req.user.id);
    if (userIndex === -1) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const { name, phone, address, district, state, pincode, farmName } = req.body;
    const user = db.users[userIndex];

    if (name) user.name = name.trim();
    if (phone) user.phone = phone.trim();
    if (address) user.address = address.trim();
    if (district) user.district = district.trim();
    if (state) user.state = state.trim();
    if (pincode) user.pincode = pincode.trim();
    if (farmName && user.role === 'farmer') user.farmName = farmName.trim();

    writeDb(db);

    const { password: _, ...userWithoutPassword } = user;
    return res.json({ success: true, message: 'Profile updated successfully!', user: userWithoutPassword });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to update profile.' });
  }
});

module.exports = {
  router,
  authenticateToken,
  JWT_SECRET
};
