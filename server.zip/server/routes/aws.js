const express = require('express');
const router = express.Router();
const { readDb, writeDb } = require('../data/store');

// GET /api/aws/telemetry - Live AWS Cloud metrics and architecture status
router.get('/telemetry', (req, res) => {
  try {
    const db = readDb();
    const aws = db.awsSimulation || {};

    // Dynamic metrics calculation
    const totalUsers = db.users ? db.users.length : 0;
    const totalProducts = db.products ? db.products.length : 0;
    const totalOrders = db.orders ? db.orders.length : 0;

    // Synchronize DynamoDB table counts
    if (aws.dynamoDb && aws.dynamoDb.tables) {
      aws.dynamoDb.tables.forEach(table => {
        if (table.name === 'TN_Farmer_Users') table.itemCount = totalUsers;
        if (table.name === 'TN_Farmer_Products') table.itemCount = totalProducts;
        if (table.name === 'TN_Farmer_Orders') table.itemCount = totalOrders;
      });
    }

    return res.json({
      success: true,
      timestamp: new Date().toISOString(),
      architecture: {
        projectName: 'Farmer Produce Marketing Platform',
        cloudProvider: 'Amazon Web Services (AWS)',
        region: aws.region || 'ap-south-1 (Asia Pacific - Mumbai)',
        servicesUsed: [
          {
            service: 'Amazon EC2 / AWS App Runner',
            role: 'Compute Layer',
            description: 'Hosts the Node.js / Express microservices backend with autoscaling and reverse proxy.'
          },
          {
            service: 'Amazon S3',
            role: 'Object Storage',
            description: 'Stores farmer crop photos, harvest certificates, and PDF delivery challans.'
          },
          {
            service: 'Amazon DynamoDB',
            role: 'NoSQL Database',
            description: 'Provides low-latency state persistence for farmer listings, customer carts, and order logistics.'
          },
          {
            service: 'Amazon SNS',
            role: 'Notification Service',
            description: 'Publishes instant SMS alerts to farmers for incoming orders and to customers for transit milestones.'
          },
          {
            service: 'Amazon SQS',
            role: 'Message Queuing',
            description: 'Buffers surge orders during harvest seasons, decoupling order intake from logistics dispatching.'
          },
          {
            service: 'Amazon CloudWatch',
            role: 'Monitoring & Logging',
            description: 'Aggregates API latency metrics, server health heartbeats, and audit logs for administrative security.'
          }
        ]
      },
      metrics: aws
    });
  } catch (err) {
    console.error('AWS Telemetry error:', err);
    return res.status(500).json({ success: false, message: 'Could not load AWS telemetry.' });
  }
});

// POST /api/aws/simulate-sns - Trigger a sample test SMS/Email via Amazon SNS
router.post('/simulate-sns', (req, res) => {
  try {
    const { recipient, message, type } = req.body;
    const db = readDb();

    if (!db.awsSimulation) db.awsSimulation = {};
    if (!db.awsSimulation.sns) db.awsSimulation.sns = { totalNotificationsSent: 0, recentDispatches: [] };

    const newDispatch = {
      id: `sns-test-${Date.now()}`,
      type: type || 'SMS',
      recipient: recipient || '+91 9444012345 (Tamil Nadu Farmer)',
      message: message || 'Test agricultural advisory notification dispatched via Amazon SNS.',
      timestamp: new Date().toISOString(),
      status: 'DELIVERED'
    };

    db.awsSimulation.sns.totalNotificationsSent += 1;
    db.awsSimulation.sns.recentDispatches.unshift(newDispatch);

    if (db.awsSimulation.cloudWatch?.recentLogs) {
      db.awsSimulation.cloudWatch.recentLogs.unshift({
        timestamp: new Date().toISOString(),
        level: 'INFO',
        service: 'Amazon-SNS',
        message: `SNS Topic TN_FarmerProduceAlerts dispatched ${newDispatch.type} to ${newDispatch.recipient}`
      });
    }

    writeDb(db);

    return res.json({ success: true, message: 'Simulated SNS notification sent successfully!', dispatch: newDispatch });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to simulate SNS dispatch.' });
  }
});

module.exports = router;
