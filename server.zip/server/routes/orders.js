const express = require('express');
const router = express.Router();
const { readDb, writeDb } = require('../data/store');
const { authenticateToken } = require('./auth');

// Map districts to nearby collection centres and district hubs in Tamil Nadu
function resolveLogisticsDefaults(farmerDistrict, customerDistrict, db) {
  // Find matching or fallback collection centre
  let centre = db.collectionCentres.find(c => c.district.toLowerCase() === (farmerDistrict || '').toLowerCase());
  if (!centre) centre = db.collectionCentres[0];

  // Find matching or fallback district hub
  let hub = db.districtHubs.find(h => h.district.toLowerCase() === (customerDistrict || '').toLowerCase());
  if (!hub) hub = db.districtHubs[0];

  // Find delivery partner
  let partner = db.deliveryPartners.find(p => p.district.toLowerCase() === (customerDistrict || '').toLowerCase());
  if (!partner) partner = db.deliveryPartners[0];

  return {
    collectionCentre: centre ? `${centre.name} [Incharge: ${centre.incharge}]` : 'Madurai Agri Collection Center',
    districtHub: hub ? `${hub.name} [Mgr: ${hub.manager}]` : 'Chennai Central Agro Logistics Hub',
    deliveryPerson: partner ? `${partner.name} (${partner.agency} - ${partner.phone})` : 'Ravi Kumar (SpeedAgri - +91 9876543210)'
  };
}

// POST /api/orders - Customer places an order
router.post('/', authenticateToken, (req, res) => {
  try {
    if (req.user.role !== 'customer') {
      return res.status(403).json({ success: false, message: 'Only customers can place produce orders.' });
    }

    const { items, deliveryAddress, paymentMethod, paymentDetails } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Order items are required.' });
    }

    if (!deliveryAddress || !deliveryAddress.street || !deliveryAddress.district || !deliveryAddress.pincode) {
      return res.status(400).json({ success: false, message: 'Full delivery address with district and pincode is required.' });
    }

    const db = readDb();
    const orderItems = [];
    let subtotal = 0;
    let primaryFarmerDistrict = 'Tamil Nadu';

    // Validate products and check inventory
    for (const item of items) {
      const product = db.products.find(p => p.id === item.productId);
      if (!product) {
        return res.status(404).json({ success: false, message: `Product ${item.name || item.productId} not found.` });
      }

      const qty = parseFloat(item.quantity);
      if (qty <= 0) {
        return res.status(400).json({ success: false, message: `Invalid quantity for ${product.name}.` });
      }

      if (product.availableQuantity < qty) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for ${product.name}. Only ${product.availableQuantity} ${product.unit} available.`
        });
      }

      // Decrement stock
      product.availableQuantity -= qty;

      const itemTotal = product.price * qty;
      subtotal += itemTotal;
      primaryFarmerDistrict = product.district || primaryFarmerDistrict;

      orderItems.push({
        productId: product.id,
        name: product.name,
        category: product.category,
        price: product.price,
        unit: product.unit,
        quantity: qty,
        farmerId: product.farmerId,
        farmerName: product.farmerName,
        farmerDistrict: product.district,
        image: product.image
      });
    }

    // Delivery fee rule: Free above 500 INR, else 40 INR
    const deliveryFee = subtotal >= 500 ? 0 : 40;
    const total = subtotal + deliveryFee;

    const orderId = `ORD-TN-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    const logisticsAssignment = resolveLogisticsDefaults(primaryFarmerDistrict, deliveryAddress.district, db);

    const newOrder = {
      id: orderId,
      customerId: req.user.id,
      customerName: deliveryAddress.name || req.user.name,
      customerEmail: req.user.email,
      customerPhone: deliveryAddress.phone || req.body.phone || '9884012345',
      deliveryAddress: {
        name: deliveryAddress.name || req.user.name,
        phone: deliveryAddress.phone || '9884012345',
        street: deliveryAddress.street,
        district: deliveryAddress.district,
        state: deliveryAddress.state || 'Tamil Nadu',
        pincode: deliveryAddress.pincode
      },
      items: orderItems,
      subtotal,
      deliveryFee,
      total,
      payment: {
        method: paymentMethod || 'UPI',
        upiId: paymentDetails?.upiId || (paymentMethod === 'UPI' ? `${req.user.name.toLowerCase().replace(/\s+/g, '')}@okaxis` : undefined),
        cardNumber: paymentDetails?.cardNumber ? `•••• •••• •••• ${paymentDetails.cardNumber.slice(-4)}` : undefined,
        transactionId: `TXN-AWS-${Date.now()}-${Math.floor(100 + Math.random() * 899)}`,
        status: paymentMethod === 'COD' ? 'PENDING' : 'PAID',
        paidAt: paymentMethod === 'COD' ? null : now
      },
      orderStatus: 'PLACED',
      logistics: {
        collectionCentre: logisticsAssignment.collectionCentre,
        districtHub: logisticsAssignment.districtHub,
        deliveryPerson: logisticsAssignment.deliveryPerson,
        timeline: [
          {
            status: 'PLACED',
            title: 'Order Placed & AWS SQS Enqueued',
            location: `${deliveryAddress.district}, Tamil Nadu`,
            timestamp: now,
            note: `Simulated Payment of ₹${total} authorized. Order dispatched to Agri AWS SQS processing queue.`
          }
        ]
      },
      createdAt: now,
      updatedAt: now
    };

    db.orders.unshift(newOrder);

    // Update DynamoDB & SQS simulation stats
    const ordersTable = db.awsSimulation?.dynamoDb?.tables.find(t => t.name === 'TN_Farmer_Orders');
    if (ordersTable) ordersTable.itemCount += 1;

    // Send SNS Simulation Notifications
    if (db.awsSimulation?.sns) {
      db.awsSimulation.sns.totalNotificationsSent += 2;
      db.awsSimulation.sns.recentDispatches.unshift({
        id: `sns-msg-${Date.now()}`,
        type: 'SMS',
        recipient: `${newOrder.customerPhone} (Customer: ${newOrder.customerName})`,
        message: `Order #${newOrder.id} placed successfully! Total: ₹${total}. Village Hub: ${newOrder.logistics.collectionCentre}`,
        timestamp: now,
        status: 'DELIVERED'
      });

      // Notify first farmer
      const fItem = orderItems[0];
      db.awsSimulation.sns.recentDispatches.unshift({
        id: `sns-msg-${Date.now() + 1}`,
        type: 'EMAIL',
        recipient: `${fItem.farmerName} [Farmer Hub]`,
        message: `New Order Alert #${newOrder.id}! ${orderItems.length} items ordered for ₹${total}. Prepare harvest dispatch.`,
        timestamp: now,
        status: 'DELIVERED'
      });

      if (db.awsSimulation.sns.recentDispatches.length > 25) {
        db.awsSimulation.sns.recentDispatches.splice(25);
      }
    }

    if (db.awsSimulation?.cloudWatch?.recentLogs) {
      db.awsSimulation.cloudWatch.recentLogs.unshift({
        timestamp: now,
        level: 'INFO',
        service: 'AWS-StepFunctions/SQS',
        message: `Order ${newOrder.id} state machine initiated. Total: ₹${total} [Tamil Nadu Logistics Network]`
      });
      if (db.awsSimulation.cloudWatch.recentLogs.length > 20) {
        db.awsSimulation.cloudWatch.recentLogs.pop();
      }
    }

    writeDb(db);

    return res.status(201).json({
      success: true,
      message: 'Order placed successfully!',
      order: newOrder
    });
  } catch (err) {
    console.error('Error placing order:', err);
    return res.status(500).json({ success: false, message: 'Could not complete order placement.' });
  }
});

// GET /api/orders - Filtered by role
router.get('/', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    let orders = [...(db.orders || [])];

    if (req.user.role === 'customer') {
      orders = orders.filter(o => o.customerId === req.user.id);
    } else if (req.user.role === 'farmer') {
      orders = orders.filter(o => o.items.some(i => i.farmerId === req.user.id));
    }
    // Admin sees all orders

    return res.json({ success: true, count: orders.length, orders });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Could not fetch orders.' });
  }
});

// GET /api/orders/:id - Single order details
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    const order = db.orders.find(o => o.id === req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    // Role check
    if (
      req.user.role === 'customer' && order.customerId !== req.user.id ||
      req.user.role === 'farmer' && !order.items.some(i => i.farmerId === req.user.id) && req.user.role !== 'admin'
    ) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    return res.json({ success: true, order });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error retrieving order.' });
  }
});

// PUT /api/orders/:id/farmer-action - Farmer accepts or rejects
router.put('/:id/farmer-action', authenticateToken, (req, res) => {
  try {
    if (req.user.role !== 'farmer' && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Only farmers can update order status.' });
    }

    const { action, note } = req.body; // 'accept', 'reject', 'dispatch'
    const db = readDb();
    const order = db.orders.find(o => o.id === req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    const now = new Date().toISOString();

    if (action === 'accept') {
      order.orderStatus = 'FARMER_CONFIRMED';
      order.logistics.timeline.push({
        status: 'FARMER_CONFIRMED',
        title: 'Farmer Confirmed Order & Packaged Produce',
        location: `${order.items[0]?.farmerDistrict || 'Tamil Nadu'} Farm Origin`,
        timestamp: now,
        note: note || 'Farmer verified organic harvest quality and prepared crate for collection centre.'
      });
    } else if (action === 'dispatch') {
      order.orderStatus = 'DISPATCHED_TO_COLLECTION_CENTRE';
      order.logistics.timeline.push({
        status: 'DISPATCHED_TO_COLLECTION_CENTRE',
        title: 'Dispatched to Village Collection Centre',
        location: order.logistics.collectionCentre,
        timestamp: now,
        note: note || `Dispatched by farmer to ${order.logistics.collectionCentre}.`
      });
    } else if (action === 'reject') {
      order.orderStatus = 'CANCELLED';
      order.logistics.timeline.push({
        status: 'CANCELLED',
        title: 'Order Cancelled by Farmer',
        location: 'Farm Origin',
        timestamp: now,
        note: note || 'Produce currently unavailable due to unexpected harvest weather condition.'
      });
    }

    order.updatedAt = now;

    // Send SNS Alert
    if (db.awsSimulation?.sns) {
      db.awsSimulation.sns.recentDispatches.unshift({
        id: `sns-msg-${Date.now()}`,
        type: 'SMS',
        recipient: `${order.customerPhone} (${order.customerName})`,
        message: `Order #${order.id} update: Status changed to ${order.orderStatus}.`,
        timestamp: now,
        status: 'DELIVERED'
      });
    }

    writeDb(db);

    return res.json({ success: true, message: `Order status updated to ${order.orderStatus}`, order });
  } catch (err) {
    console.error('Farmer action error:', err);
    return res.status(500).json({ success: false, message: 'Failed to update order action.' });
  }
});

module.exports = router;
