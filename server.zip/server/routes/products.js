const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { readDb, writeDb } = require('../data/store');
const { authenticateToken } = require('./auth');

// Multer storage setup
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, 'produce-' + uniqueSuffix + ext);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed.'));
    }
  }
});

// GET /api/products - Browse, search, filter products
router.get('/', (req, res) => {
  try {
    const { search, category, district, minPrice, maxPrice, sort, farmerId } = req.query;
    const db = readDb();
    let list = [...(db.products || [])];

    if (farmerId) {
      list = list.filter(p => p.farmerId === farmerId);
    }

    if (search && search.trim() !== '') {
      const q = search.trim().toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.district.toLowerCase().includes(q) ||
        p.farmerName.toLowerCase().includes(q)
      );
    }

    if (category && category !== 'All') {
      list = list.filter(p => p.category === category);
    }

    if (district && district !== 'All') {
      list = list.filter(p => p.district.toLowerCase() === district.toLowerCase());
    }

    if (minPrice) {
      list = list.filter(p => p.price >= parseFloat(minPrice));
    }

    if (maxPrice) {
      list = list.filter(p => p.price <= parseFloat(maxPrice));
    }

    if (sort === 'price-asc') {
      list.sort((a, b) => a.price - b.price);
    } else if (sort === 'price-desc') {
      list.sort((a, b) => b.price - a.price);
    } else if (sort === 'name') {
      list.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      // Newest first
      list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    return res.json({ success: true, count: list.length, products: list });
  } catch (err) {
    console.error('Error fetching products:', err);
    return res.status(500).json({ success: false, message: 'Could not fetch products.' });
  }
});

// GET /api/products/:id - Single product details
router.get('/:id', (req, res) => {
  try {
    const db = readDb();
    const product = db.products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }
    return res.json({ success: true, product });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error retrieving product.' });
  }
});

// POST /api/products - Farmer adds new product
router.post('/', authenticateToken, upload.single('image'), (req, res) => {
  try {
    if (req.user.role !== 'farmer' && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Only registered farmers can list products.' });
    }

    const { name, category, price, unit, availableQuantity, location, description, organicCertification, harvestDate } = req.body;

    if (!name || !price || !availableQuantity) {
      return res.status(400).json({ success: false, message: 'Name, price, and available quantity are required.' });
    }

    const db = readDb();
    const farmer = db.users.find(u => u.id === req.user.id);
    const farmerName = farmer ? farmer.name : req.user.name;
    const farmerDistrict = farmer ? farmer.district : req.user.district;

    let imageUrl = '/assets/products/ponni_rice.jpg';
    if (req.file) {
      imageUrl = '/uploads/' + req.file.filename;
    } else if (req.body.imageUrl) {
      imageUrl = req.body.imageUrl;
    }

    const newProduct = {
      id: `prod-${Date.now()}`,
      farmerId: req.user.id,
      farmerName: farmerName,
      name: name.trim(),
      category: category || 'Vegetables',
      price: parseFloat(price),
      unit: unit || 'kg',
      availableQuantity: parseFloat(availableQuantity),
      district: farmerDistrict || 'Tamil Nadu',
      location: location || `${farmerDistrict}, Tamil Nadu`,
      description: description || 'Fresh farm harvested organic produce.',
      image: imageUrl,
      organicCertification: organicCertification || 'Standard Farmer Verified',
      harvestDate: harvestDate || new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };

    db.products.unshift(newProduct);

    // Update simulated AWS stats
    const productsTable = db.awsSimulation?.dynamoDb?.tables.find(t => t.name === 'TN_Farmer_Products');
    if (productsTable) productsTable.itemCount += 1;

    if (req.file && db.awsSimulation?.s3) {
      db.awsSimulation.s3.totalObjects += 1;
      db.awsSimulation.s3.storageSizeBytes += req.file.size;
    }

    if (db.awsSimulation?.cloudWatch?.recentLogs) {
      db.awsSimulation.cloudWatch.recentLogs.unshift({
        timestamp: new Date().toISOString(),
        level: 'INFO',
        service: 'Amazon-S3/DynamoDB',
        message: `Farmer ${farmerName} uploaded ${newProduct.name} [S3 asset synced]`
      });
      if (db.awsSimulation.cloudWatch.recentLogs.length > 20) {
        db.awsSimulation.cloudWatch.recentLogs.pop();
      }
    }

    writeDb(db);

    return res.status(201).json({
      success: true,
      message: 'Product listed successfully!',
      product: newProduct
    });
  } catch (err) {
    console.error('Error adding product:', err);
    return res.status(500).json({ success: false, message: 'Could not add product.' });
  }
});

// PUT /api/products/:id - Farmer updates product
router.put('/:id', authenticateToken, upload.single('image'), (req, res) => {
  try {
    const db = readDb();
    const product = db.products.find(p => p.id === req.params.id);

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    if (req.user.role !== 'admin' && product.farmerId !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized to edit this product.' });
    }

    const { name, category, price, unit, availableQuantity, location, description, organicCertification, harvestDate } = req.body;

    if (name) product.name = name.trim();
    if (category) product.category = category;
    if (price !== undefined) product.price = parseFloat(price);
    if (unit) product.unit = unit;
    if (availableQuantity !== undefined) product.availableQuantity = parseFloat(availableQuantity);
    if (location) product.location = location.trim();
    if (description) product.description = description.trim();
    if (organicCertification) product.organicCertification = organicCertification.trim();
    if (harvestDate) product.harvestDate = harvestDate;

    if (req.file) {
      product.image = '/uploads/' + req.file.filename;
      if (db.awsSimulation?.s3) {
        db.awsSimulation.s3.totalObjects += 1;
        db.awsSimulation.s3.storageSizeBytes += req.file.size;
      }
    }

    product.updatedAt = new Date().toISOString();

    writeDb(db);

    return res.json({ success: true, message: 'Product updated successfully!', product });
  } catch (err) {
    console.error('Error updating product:', err);
    return res.status(500).json({ success: false, message: 'Could not update product.' });
  }
});

// DELETE /api/products/:id - Farmer deletes product
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    const db = readDb();
    const productIndex = db.products.findIndex(p => p.id === req.params.id);

    if (productIndex === -1) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const product = db.products[productIndex];
    if (req.user.role !== 'admin' && product.farmerId !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized to delete this product.' });
    }

    db.products.splice(productIndex, 1);

    const productsTable = db.awsSimulation?.dynamoDb?.tables.find(t => t.name === 'TN_Farmer_Products');
    if (productsTable && productsTable.itemCount > 0) productsTable.itemCount -= 1;

    writeDb(db);

    return res.json({ success: true, message: 'Product deleted successfully.' });
  } catch (err) {
    console.error('Error deleting product:', err);
    return res.status(500).json({ success: false, message: 'Could not delete product.' });
  }
});

module.exports = router;
