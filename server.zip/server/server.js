const express = require('express');
const cors = require('cors');
const path = require('path');
const { initSeedData, readDb, writeDb } = require('./data/store');

// Ensure database is initialized
initSeedData();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CloudWatch Simulated Request Logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (req.url.startsWith('/api') && !req.url.includes('/aws/telemetry')) {
      try {
        const db = readDb();
        if (db.awsSimulation?.cloudWatch?.recentLogs) {
          db.awsSimulation.cloudWatch.recentLogs.unshift({
            timestamp: new Date().toISOString(),
            level: res.statusCode >= 400 ? 'WARN' : 'INFO',
            service: 'AWS-AppRunner/ALB',
            message: `${res.statusCode} ${req.method} ${req.url} - ${duration}ms`
          });
          if (db.awsSimulation.cloudWatch.recentLogs.length > 20) {
            db.awsSimulation.cloudWatch.recentLogs.pop();
          }
          if (db.awsSimulation?.ec2) {
            db.awsSimulation.ec2.totalRequestsHandled = (db.awsSimulation.ec2.totalRequestsHandled || 0) + 1;
          }
          writeDb(db);
        }
      } catch (e) {
        // Ignore telemetry write errors
      }
    }
  });
  next();
});

// Static assets
app.use(express.static(path.join(__dirname, '../public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/assets', express.static(path.join(__dirname, '../public/assets')));

// API Routes
app.use('/api/auth', require('./routes/auth').router);
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/aws', require('./routes/aws'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    service: 'Farmer Produce Marketing API',
    cloud: 'AWS Elastic Beanstalk / App Runner',
    region: 'ap-south-1',
    timestamp: new Date().toISOString()
  });
});

// Fallback to index.html for SPA client-side routing
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🌱 Farmer Produce Marketing Platform is running!`);
  console.log(`🚀 Local URL: http://localhost:${PORT}`);
  console.log(`☁️  AWS Cloud Architecture Simulator: http://localhost:${PORT}/#aws`);
  console.log(`====================================================`);
});
